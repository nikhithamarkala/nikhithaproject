package com.comcast.xfinity.mobile.notifications.repository;

import static org.junit.Assert.*;

import org.junit.Test;
import com.comcast.xfinity.mobile.notifications.config.properties.MerlotProperties;
import com.comcast.xfinity.mobile.notifications.domain.FraudOrderEventData;
import com.comcast.xfinity.mobile.notifications.domain.grapevine.FraudTicketPayload;
import com.comcast.xfinity.mobile.notifications.service.OrderNotificationService;
import com.comcast.xfinity.mobile.notifications.service.remote.ProspectServiceClient;
import com.comcast.xfinity.mobile.util.logging.LogAction;
import com.comcast.xfinity.mobile.utils.logging.model.JsonUtils;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ MerlotClient.class, JsonUtils.class })
public class MerlotClientTest {

	@Mock
	private MerlotClient merlotclient;
	@Mock
	private MerlotProperties merlotProperties;
	@Mock
	private CimaTokenRepository cimaClient;
	@Mock
	FraudOrderEventData fraudOrderData;
	@Mock
	FraudTicketPayload ticketBody;

	@Mock
	BasicRestClient restClient;

	private List<String> email = new ArrayList<>();
	private List<String> phone = new ArrayList<>();
	private List<String> productSkus = new ArrayList<>();

	Map<String, String> headers = new HashMap<>();
	Map<String, String> parameters = new HashMap<>();
	
	

	@Before
	public void setUp() throws Exception {

		productSkus.add("1234");

		fraudOrderData = new FraudOrderEventData();
		fraudOrderData.setOrderType("123");
		fraudOrderData.setModestoAccountNumber("");
		fraudOrderData.setComcastAccountNumber("8087300020080902");
		fraudOrderData.setMspOrderId("");
		fraudOrderData.setFirstName("AEQUIPMGMT106");
		fraudOrderData.setLastName("TEST");
		fraudOrderData.setTimestamp("2018-08-30T13:47:37.630Z");
		fraudOrderData.setFraudScore("");
		fraudOrderData.setContactEmailId("ibbfiekgccfjh@gmail.com");
		fraudOrderData.setContactPhoneNumber("2111129378");
		fraudOrderData.setContactEmailAddresses(email);
		fraudOrderData.setFraudReason(null);
		fraudOrderData.setOrderCreationDate("");
		fraudOrderData.setProductSkus(productSkus);

		headers.put("Content-Type", "application/json");

		ticketBody = new FraudTicketPayload();
		ticketBody.setProductSkus("");
		ticketBody.setOrderType("12345");
		ticketBody.setModestoAccountNumber(null);
		ticketBody.setComcastAccountNumber("8087300020080902");
		ticketBody.setMspOrderId("");
		ticketBody.setFirstName("AEQUIPMGMT106");
		ticketBody.setLastName("TEST");
		ticketBody.setTimestamp("2018-08-30T13:47:37.630Z");
		ticketBody.setFraudScore("");
		ticketBody.setContactEmailId("ibbfiekgccfjh@gmail.com");
		ticketBody.setContactPhoneNumber("2111129378");
		ticketBody.setFraudReason("");
		ticketBody.setOrderCreationDate("");

		merlotclient = PowerMockito.spy(new MerlotClient());

		String baseUrl = "http://142.136.162.35:9999";
		Mockito.when(merlotProperties.getBaseUrl()).thenReturn(baseUrl);
		String merlotEndpoint = "/merlot/api/v1.6/ticket/{ticketCategory}";
		Mockito.when(merlotProperties.getMerlotEndpoint()).thenReturn(merlotEndpoint);

		ReflectionTestUtils.setField(merlotclient, "merlotProperties", merlotProperties, MerlotProperties.class);
		ReflectionTestUtils.setField(merlotclient, "cimaClient", cimaClient, CimaTokenRepository.class);
		
	}
	
	@Test
	public void assertSendlogFraudOrderTicket() throws Exception {

		// Arrange
		String serviceUrl = "http://142.136.162.35:9999/merlot/api/v1.6/ticket/fraud-review";
		String response = "{\"success\":true}";
		String merlotTicketRequest = "{\"orderType\":null,\"modestoAccountNumber\":null,\"comcastAccountNumber\":\"\",\"mspOrderId\":\"\",\"firstName\":\"\",\"lastName\":\"\",\"timestamp\":\"\",\"fraudScore\":\"\",\"contactEmailId\":\"\",\"contactPhoneNumber\":\"\",\"fraudReason\":\"\",\"orderCreationDate\":\"\",\"productSkus\":\"\"}";
		String ticketCategory = "fraud-review";

		Mockito.when(merlotProperties.getTicketCategory()).thenReturn(ticketCategory);
		PowerMockito.doReturn(serviceUrl).when(merlotclient, "createServiceUrl", Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString());
		PowerMockito.doReturn(ticketBody).when(merlotclient, "buildMerlotTicketRequest", fraudOrderData);
		PowerMockito.stub(PowerMockito.method(JsonUtils.class, "marshal")).toReturn(merlotTicketRequest);
		PowerMockito.doReturn(restClient).when(merlotclient, "createMerlotRestClient");
		Mockito.when(restClient.doPost(serviceUrl, merlotTicketRequest, headers, parameters)).thenReturn(response);
		
		// Act
        String Response = merlotclient.logFraudOrderTicket(fraudOrderData);

		// Assert
        assertEquals("true", Response.substring(11, 15));
    }
	
	@Test
	public void assertbuildMerlotTicketRequest() throws Exception {
      // Arrange

	  // Act
	  FraudTicketPayload fraudTicketPayload = ReflectionTestUtils.invokeMethod(merlotclient,"buildMerlotTicketRequest", fraudOrderData);
	 
	  // Assert
	  assertEquals("AEQUIPMGMT106", fraudTicketPayload.getFirstName());
    }
	
	@Test
	public void assertcreateServiceUrl() throws Exception {
		// Arrange
		String baseUrl = "http://142.136.162.35:9999";
		String merlotEndpoint = "/merlot/api/v1.6/ticket/{ticketCategory}";
		String ticketCategory = "fraud-review";

		// Act
		String serUrl = ReflectionTestUtils.invokeMethod(merlotclient, "createServiceUrl", baseUrl, merlotEndpoint, ticketCategory);
				
		// Assert
		assertEquals("http://142.136.162.35:9999/merlot/api/v1.6/ticket/fraud-review", serUrl);

	}
}
