package com.comcast.xfinity.mobile.notifications.service;

import com.comcast.xfinity.mobile.notifications.domain.OrderPlacedEventData;
import com.comcast.xfinity.mobile.notifications.domain.OrderStatusChangeEventData;
import com.comcast.xfinity.mobile.notifications.domain.account.AccountInformation;
import com.comcast.xfinity.mobile.notifications.domain.common.ParameterizedMspResponse;
import com.comcast.xfinity.mobile.notifications.repository.GrapevineClient;
import com.comcast.xfinity.mobile.notifications.service.remote.ProspectServiceClient;
import com.google.gson.Gson;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;

@RunWith(PowerMockRunner.class)
@PrepareForTest(OrderNotificationService.class)
@SuppressWarnings("unchecked")
public class OrderNotificationServiceTest {
	
	@InjectMocks
	private OrderNotificationService orderNotificationService;
	@Mock
	private GrapevineClient grapevineClient;
	@Mock
	private ProspectServiceClient prospectService;
	@Mock
	OrderPlacedEventData orderData;
	@Mock
	OrderStatusChangeEventData orderCancelledData;

	@Before
	public void setUp() throws Exception {
		orderData = new OrderPlacedEventData();
		orderData.setOrderId("123455");
		orderData.setAccountGuid("10000033440");
		orderData.setClientId("");
		orderData.setArterraOrderId("");
		orderData.setOrderTotal("");
		orderData.setOrderType("");
		orderData.setFirstName("");
		orderData.setLastName("");
		orderData.setTimestamp("");
		orderData.setContactPhoneNumbers(null);
		orderData.setContactEmailAddresses(null);
		orderData.setProductSkus(null);
		orderData.setAvailabilityDescription(null);
		
		orderCancelledData = new OrderStatusChangeEventData();
		orderCancelledData.setOrderSubmissionDate(null);
		orderCancelledData.setContactEmailId(null);
		orderCancelledData.setContactPhoneNumber(null);
		orderCancelledData.setFirstName("AEQUIPMGMT106");
		orderCancelledData.setLastName("TEST");
		orderCancelledData.setTimestamp(null);
		orderCancelledData.setOrderId(null);
		orderCancelledData.setArterraOrderId(null);
		orderCancelledData.setCustomerGuid(null);
		orderCancelledData.setAccountGuid("10000033440");
		orderCancelledData.setContactPhoneNumbers(null);
		orderCancelledData.setContactEmailAddresses(null);
		orderCancelledData.setFraudStatus(null);
		
		grapevineClient = Mockito.mock(GrapevineClient.class);
		prospectService = Mockito.mock(ProspectServiceClient.class);
		
		orderNotificationService = PowerMockito.spy(new OrderNotificationService());
		
		ReflectionTestUtils.setField(orderNotificationService, "grapevineClient", grapevineClient,
				GrapevineClient.class);
		ReflectionTestUtils.setField(orderNotificationService, "prospectService", prospectService,
				ProspectServiceClient.class);
		
	}
	@Test
	public void assertSendOrderPlacedNotification() throws Exception {
		// Arrange
		boolean accountInfoUpdated = true;
		String gvResponse = "{  \r\n" + "   \"code\":\"NC_90001\",\r\n" + "   \"message\":\"Success\",\r\n"
				+ "   \"moreInfo\":null,\r\n" + "   \"payload\":null,\r\n" + "   \"httpCode\":\"OK\"\r\n" + "}";
		
		PowerMockito.when(grapevineClient.sendOrderCreateNotification(orderData)).thenReturn(gvResponse);

		PowerMockito.doReturn(accountInfoUpdated).when(orderNotificationService, "populateAccountData", orderData);
		// Act
		String response = orderNotificationService.sendOrderPlacedNotification(orderData);
		// Assert
		assertEquals("Success", response.substring(42, 49));

	}
	
	@Test
	public void assertSendOrderCancelledNotification() throws Exception {
		// Arrange
		boolean accountInfoUpdated = true;
		String gvResponse = "{  \r\n" + "   \"code\":\"NC_90001\",\r\n" + "   \"message\":\"Success\",\r\n"
				+ "   \"moreInfo\":null,\r\n" + "   \"payload\":null,\r\n" + "   \"httpCode\":\"OK\"\r\n" + "}";
		
		PowerMockito.when(grapevineClient.sendOrderCancelledNotification(orderCancelledData)).thenReturn(gvResponse);
		PowerMockito.doReturn(accountInfoUpdated).when(orderNotificationService, "populateAccountCancelData", orderCancelledData);
		// Act
		String response = orderNotificationService.sendOrderCancelledNotification(orderCancelledData);
		// Assert
		assertEquals("Success", response.substring(42, 49));

	}
	@Test
	public void assertpopulateAccountDataNotNull() throws Exception {
		// Arrange
		String accountGuid = "10000033440";
		String accInfo = " {\r\n" + 
				"    \"accountInfo\": {\r\n" + 
				"      \"accountGuid\": \"10000033440\",\r\n" + 
				"      \"comcastAccountNumber\": \"8087300020080902\",\r\n" + 
				"      \"firstName\": \"AEQUIPMGMT106\",\r\n" + 
				"      \"lastName\": \"TEST\",\r\n" + 
				"      \"ssn\": \"\",\r\n" + 
				"      \"isEmployee\": false,\r\n" + 
				"      \"serviceAddress\": {\r\n" + 
				"        \"address1\": \"2401 QARESI DRIVE\",\r\n" + 
				"        \"address2\": \"PORTAL APT 01\",\r\n" + 
				"        \"city\": \"ST LOUIS\",\r\n" + 
				"        \"state\": \"MO\",\r\n" + 
				"        \"zip\": \"631320000\",\r\n" + 
				"        \"latitude\": \"\",\r\n" + 
				"        \"longitude\": \"\",\r\n" + 
				"        \"accountType\": \"RESIDENTIAL\"\r\n" + 
				"      },\r\n" + 
				"      \"billingAddress\": {\r\n" + 
				"        \"address1\": \"2401 QARESI DRIVE\",\r\n" + 
				"        \"address2\": \"PORTAL APT 01\",\r\n" + 
				"        \"city\": \"ST LOUIS\",\r\n" + 
				"        \"state\": \"MO\",\r\n" + 
				"        \"zip\": \"63132\",\r\n" + 
				"        \"latitude\": \"\",\r\n" + 
				"        \"longitude\": \"\",\r\n" + 
				"        \"accountType\": \"RESIDENTIAL\"\r\n" + 
				"      },\r\n" + 
				"      \"accountStatus\": \"Active\",\r\n" + 
				"      \"languagePreference\": \"ENGLISH\"\r\n" + 
				"    },\r\n" + 
				"    \"users\": [\r\n" + 
				"      {\r\n" + 
				"        \"comcastUserGuid\": \"10000033440\",\r\n" + 
				"        \"firstName\": \"AEQUIPMGMT106\",\r\n" + 
				"        \"lastName\": \"TEST\",\r\n" + 
				"        \"email\": \"\",\r\n" + 
				"        \"role\": \"Primary\",\r\n" + 
				"        \"dob\": \"\"\r\n" + 
				"      }\r\n" + 
				"    ]\r\n" + 
				"  }";
		
		AccountInformation accInformation = new Gson().fromJson(accInfo, AccountInformation.class);
		@SuppressWarnings("rawtypes")
		ParameterizedMspResponse parameterizedMspResponse = new ParameterizedMspResponse();
		parameterizedMspResponse.setData(accInformation);
		ResponseEntity<ParameterizedMspResponse<AccountInformation>> accountResponse = new ResponseEntity<ParameterizedMspResponse<AccountInformation>>(parameterizedMspResponse, HttpStatus.OK);
		PowerMockito.when(prospectService.getAccountInformation(accountGuid)).thenReturn(accountResponse);
		// Act
		boolean accountInfoUpdated =ReflectionTestUtils.invokeMethod(orderNotificationService, "populateAccountData", orderData);
		// Assert
		assertEquals(true, accountInfoUpdated);
	}
	
	@Test
	public void assertpopulateAccountDataIsNull() throws Exception {
		// Arrange
		String accountGuid = "123456";
		String accInfo = " {\r\n" + 
				"    \"accountInfo\": {\r\n" + 
				"      \"accountGuid\": \"10000033440\",\r\n" + 
				"      \"comcastAccountNumber\": \"8087300020080902\",\r\n" + 
				"      \"firstName\": \"AEQUIPMGMT106\",\r\n" + 
				"      \"lastName\": \"TEST\",\r\n" + 
				"      \"ssn\": \"\",\r\n" + 
				"      \"isEmployee\": false,\r\n" + 
				"      \"serviceAddress\": {\r\n" + 
				"        \"address1\": \"2401 QARESI DRIVE\",\r\n" + 
				"        \"address2\": \"PORTAL APT 01\",\r\n" + 
				"        \"city\": \"ST LOUIS\",\r\n" + 
				"        \"state\": \"MO\",\r\n" + 
				"        \"zip\": \"631320000\",\r\n" + 
				"        \"latitude\": \"\",\r\n" + 
				"        \"longitude\": \"\",\r\n" + 
				"        \"accountType\": \"RESIDENTIAL\"\r\n" + 
				"      },\r\n" + 
				"      \"billingAddress\": {\r\n" + 
				"        \"address1\": \"2401 QARESI DRIVE\",\r\n" + 
				"        \"address2\": \"PORTAL APT 01\",\r\n" + 
				"        \"city\": \"ST LOUIS\",\r\n" + 
				"        \"state\": \"MO\",\r\n" + 
				"        \"zip\": \"63132\",\r\n" + 
				"        \"latitude\": \"\",\r\n" + 
				"        \"longitude\": \"\",\r\n" + 
				"        \"accountType\": \"RESIDENTIAL\"\r\n" + 
				"      },\r\n" + 
				"      \"accountStatus\": \"Active\",\r\n" + 
				"      \"languagePreference\": \"ENGLISH\"\r\n" + 
				"    },\r\n" + 
				"    \"users\": [\r\n" + 
				"      {\r\n" + 
				"        \"comcastUserGuid\": \"10000033440\",\r\n" + 
				"        \"firstName\": \"AEQUIPMGMT106\",\r\n" + 
				"        \"lastName\": \"TEST\",\r\n" + 
				"        \"email\": \"\",\r\n" + 
				"        \"role\": \"Primary\",\r\n" + 
				"        \"dob\": \"\"\r\n" + 
				"      }\r\n" + 
				"    ]\r\n" + 
				"  }";
		
		AccountInformation accInformation = new Gson().fromJson(accInfo, AccountInformation.class);
		@SuppressWarnings("rawtypes")
		ParameterizedMspResponse parameterizedMspResponse = new ParameterizedMspResponse();
		parameterizedMspResponse.setData(accInformation);
		ResponseEntity<ParameterizedMspResponse<AccountInformation>> accountResponse = new ResponseEntity<ParameterizedMspResponse<AccountInformation>>(parameterizedMspResponse, HttpStatus.OK);
		PowerMockito.when(prospectService.getAccountInformation(accountGuid)).thenReturn(accountResponse);
		// Act
		boolean accountInfoUpdated =ReflectionTestUtils.invokeMethod(orderNotificationService, "populateAccountData", orderData);
		// Assert
		assertEquals(false, accountInfoUpdated);
	}
	
	@Test
	public void assertpopulateAccountDataUsersIsNull() throws Exception {
		// Arrange
		String accountGuid = "10000033440";
		String accInfo = "{\r\n" + 
				"    \"accountInfo\": {\r\n" + 
				"      \"accountGuid\": \"10000033440\",\r\n" + 
				"      \"comcastAccountNumber\": \"8087300020080902\",\r\n" + 
				"      \"firstName\": \"AEQUIPMGMT106\",\r\n" + 
				"      \"lastName\": \"TEST\",\r\n" + 
				"      \"ssn\": \"\",\r\n" + 
				"      \"isEmployee\": false,\r\n" + 
				"      \"serviceAddress\": {\r\n" + 
				"        \"address1\": \"2401 QARESI DRIVE\",\r\n" + 
				"        \"address2\": \"PORTAL APT 01\",\r\n" + 
				"        \"city\": \"ST LOUIS\",\r\n" + 
				"        \"state\": \"MO\",\r\n" + 
				"        \"zip\": \"631320000\",\r\n" + 
				"        \"latitude\": \"\",\r\n" + 
				"        \"longitude\": \"\",\r\n" + 
				"        \"accountType\": \"RESIDENTIAL\"\r\n" + 
				"      },\r\n" + 
				"      \"billingAddress\": {\r\n" + 
				"        \"address1\": \"2401 QARESI DRIVE\",\r\n" + 
				"        \"address2\": \"PORTAL APT 01\",\r\n" + 
				"        \"city\": \"ST LOUIS\",\r\n" + 
				"        \"state\": \"MO\",\r\n" + 
				"        \"zip\": \"63132\",\r\n" + 
				"        \"latitude\": \"\",\r\n" + 
				"        \"longitude\": \"\",\r\n" + 
				"        \"accountType\": \"RESIDENTIAL\"\r\n" + 
				"      },\r\n" + 
				"      \"accountStatus\": \"Active\",\r\n" + 
				"      \"languagePreference\": \"ENGLISH\"\r\n" + 
				"    },\r\n" + 
				"    \"users\": [\r\n" + 
				"      {\r\n" + 
				"        \"comcastUserGuid\": \"\",\r\n" + 
				"        \"firstName\": \"\",\r\n" + 
				"        \"lastName\": \"\",\r\n" + 
				"        \"email\": \"\",\r\n" + 
				"        \"role\": \"\",\r\n" + 
				"        \"dob\": \"\"\r\n" + 
				"      }\r\n" + 
				"    ]\r\n" + 
				"  }";
		
		AccountInformation accInformation = new Gson().fromJson(accInfo, AccountInformation.class);
		@SuppressWarnings("rawtypes")
		ParameterizedMspResponse parameterizedMspResponse = new ParameterizedMspResponse();
		parameterizedMspResponse.setData(accInformation);
		ResponseEntity<ParameterizedMspResponse<AccountInformation>> accountResponse = new ResponseEntity<ParameterizedMspResponse<AccountInformation>>(parameterizedMspResponse, HttpStatus.OK);
		PowerMockito.when(prospectService.getAccountInformation(accountGuid)).thenReturn(accountResponse);
		// Act
		boolean accountInfoUpdated =ReflectionTestUtils.invokeMethod(orderNotificationService, "populateAccountData", orderData);
		// Assert
		assertEquals(false, accountInfoUpdated);
	}
	
	@Test
	public void assertpopulateAccountCancelDataNotNull() throws Exception {
		// Arrange
		String accountGuid = "10000033440";
		String accInfo ="{\r\n" + 
				"    \"accountInfo\": {\r\n" + 
				"      \"accountGuid\": \"10000033440\",\r\n" + 
				"      \"comcastAccountNumber\": \"8087300020080902\",\r\n" + 
				"      \"firstName\": \"AEQUIPMGMT106\",\r\n" + 
				"      \"lastName\": \"TEST\",\r\n" + 
				"      \"ssn\": \"\",\r\n" + 
				"      \"isEmployee\": false,\r\n" + 
				"      \"serviceAddress\": {\r\n" + 
				"        \"address1\": \"2401 QARESI DRIVE\",\r\n" + 
				"        \"address2\": \"PORTAL APT 01\",\r\n" + 
				"        \"city\": \"ST LOUIS\",\r\n" + 
				"        \"state\": \"MO\",\r\n" + 
				"        \"zip\": \"631320000\",\r\n" + 
				"        \"latitude\": \"\",\r\n" + 
				"        \"longitude\": \"\",\r\n" + 
				"        \"accountType\": \"RESIDENTIAL\"\r\n" + 
				"      },\r\n" + 
				"      \"billingAddress\": {\r\n" + 
				"        \"address1\": \"2401 QARESI DRIVE\",\r\n" + 
				"        \"address2\": \"PORTAL APT 01\",\r\n" + 
				"        \"city\": \"ST LOUIS\",\r\n" + 
				"        \"state\": \"MO\",\r\n" + 
				"        \"zip\": \"63132\",\r\n" + 
				"        \"latitude\": \"\",\r\n" + 
				"        \"longitude\": \"\",\r\n" + 
				"        \"accountType\": \"RESIDENTIAL\"\r\n" + 
				"      },\r\n" + 
				"      \"accountStatus\": \"Active\",\r\n" + 
				"      \"languagePreference\": \"ENGLISH\"\r\n" + 
				"    },\r\n" + 
				"    \"users\": [\r\n" + 
				"      {\r\n" + 
				"        \"comcastUserGuid\": \"10000033440\",\r\n" + 
				"        \"firstName\": \"AEQUIPMGMT106\",\r\n" + 
				"        \"lastName\": \"TEST\",\r\n" + 
				"        \"email\": \"ibbfiekgccfjh@gmail.com\",\r\n" + 
				"        \"role\": \"Secondary\",\r\n" + 
				"        \"dob\": \"\"\r\n" + 
				"      }\r\n" + 
				"    ]\r\n" + 
				"  }";
				
		AccountInformation accInformation = new Gson().fromJson(accInfo, AccountInformation.class);
		@SuppressWarnings("rawtypes")
		ParameterizedMspResponse parameterizedMspResponse = new ParameterizedMspResponse();
		parameterizedMspResponse.setData(accInformation);
		ResponseEntity<ParameterizedMspResponse<AccountInformation>> accountResponse = new ResponseEntity<ParameterizedMspResponse<AccountInformation>>(parameterizedMspResponse, HttpStatus.OK);
		PowerMockito.when(prospectService.getAccountInformation(accountGuid)).thenReturn(accountResponse);
		// Act
		boolean accountInfoUpdated =ReflectionTestUtils.invokeMethod(orderNotificationService, "populateAccountCancelData", orderCancelledData);
		// Assert
		assertEquals(true, accountInfoUpdated);
	}
	
	@Test
	public void assertpopulateAccountCancelDataIsNull() throws Exception {
		// Arrange
		String accountGuid = "123456";
		String accInfo ="{\r\n" + 
				"    \"accountInfo\": {\r\n" + 
				"      \"accountGuid\": \"10000033440\",\r\n" + 
				"      \"comcastAccountNumber\": \"8087300020080902\",\r\n" + 
				"      \"firstName\": \"AEQUIPMGMT106\",\r\n" + 
				"      \"lastName\": \"TEST\",\r\n" + 
				"      \"ssn\": \"\",\r\n" + 
				"      \"isEmployee\": false,\r\n" + 
				"      \"serviceAddress\": {\r\n" + 
				"        \"address1\": \"2401 QARESI DRIVE\",\r\n" + 
				"        \"address2\": \"PORTAL APT 01\",\r\n" + 
				"        \"city\": \"ST LOUIS\",\r\n" + 
				"        \"state\": \"MO\",\r\n" + 
				"        \"zip\": \"631320000\",\r\n" + 
				"        \"latitude\": \"\",\r\n" + 
				"        \"longitude\": \"\",\r\n" + 
				"        \"accountType\": \"RESIDENTIAL\"\r\n" + 
				"      },\r\n" + 
				"      \"billingAddress\": {\r\n" + 
				"        \"address1\": \"2401 QARESI DRIVE\",\r\n" + 
				"        \"address2\": \"PORTAL APT 01\",\r\n" + 
				"        \"city\": \"ST LOUIS\",\r\n" + 
				"        \"state\": \"MO\",\r\n" + 
				"        \"zip\": \"63132\",\r\n" + 
				"        \"latitude\": \"\",\r\n" + 
				"        \"longitude\": \"\",\r\n" + 
				"        \"accountType\": \"RESIDENTIAL\"\r\n" + 
				"      },\r\n" + 
				"      \"accountStatus\": \"Active\",\r\n" + 
				"      \"languagePreference\": \"ENGLISH\"\r\n" + 
				"    },\r\n" + 
				"    \"users\": [\r\n" + 
				"      {\r\n" + 
				"        \"comcastUserGuid\": \"10000033440\",\r\n" + 
				"        \"firstName\": \"AEQUIPMGMT106\",\r\n" + 
				"        \"lastName\": \"TEST\",\r\n" + 
				"        \"email\": \"ibbfiekgccfjh@gmail.com\",\r\n" + 
				"        \"role\": \"Secondary\",\r\n" + 
				"        \"dob\": \"\"\r\n" + 
				"      }\r\n" + 
				"    ]\r\n" + 
				"  }";
				
		AccountInformation accInformation = new Gson().fromJson(accInfo, AccountInformation.class);
		@SuppressWarnings("rawtypes")
		ParameterizedMspResponse parameterizedMspResponse = new ParameterizedMspResponse();
		parameterizedMspResponse.setData(accInformation);
		ResponseEntity<ParameterizedMspResponse<AccountInformation>> accountResponse = new ResponseEntity<ParameterizedMspResponse<AccountInformation>>(parameterizedMspResponse, HttpStatus.OK);
		PowerMockito.when(prospectService.getAccountInformation(accountGuid)).thenReturn(accountResponse);
		// Act
		boolean accountInfoUpdated =ReflectionTestUtils.invokeMethod(orderNotificationService, "populateAccountCancelData", orderCancelledData);
		// Assert
		assertEquals(false, accountInfoUpdated);
	}
	
	
	@Test
	public void assertpopulateAccountCancelData() throws Exception {
		// Arrange
		String accountGuid = "10000033440";
		String accInfo ="{\r\n" + 
				"    \"accountInfo\": {\r\n" + 
				"      \"accountGuid\": \"10000033440\",\r\n" + 
				"      \"comcastAccountNumber\": \"8087300020080902\",\r\n" + 
				"      \"firstName\": \"AEQUIPMGMT106\",\r\n" + 
				"      \"lastName\": \"TEST\",\r\n" + 
				"      \"ssn\": \"\",\r\n" + 
				"      \"isEmployee\": false,\r\n" + 
				"      \"serviceAddress\": {\r\n" + 
				"        \"address1\": \"2401 QARESI DRIVE\",\r\n" + 
				"        \"address2\": \"PORTAL APT 01\",\r\n" + 
				"        \"city\": \"ST LOUIS\",\r\n" + 
				"        \"state\": \"MO\",\r\n" + 
				"        \"zip\": \"631320000\",\r\n" + 
				"        \"latitude\": \"\",\r\n" + 
				"        \"longitude\": \"\",\r\n" + 
				"        \"accountType\": \"RESIDENTIAL\"\r\n" + 
				"      },\r\n" + 
				"      \"billingAddress\": {\r\n" + 
				"        \"address1\": \"2401 QARESI DRIVE\",\r\n" + 
				"        \"address2\": \"PORTAL APT 01\",\r\n" + 
				"        \"city\": \"ST LOUIS\",\r\n" + 
				"        \"state\": \"MO\",\r\n" + 
				"        \"zip\": \"63132\",\r\n" + 
				"        \"latitude\": \"\",\r\n" + 
				"        \"longitude\": \"\",\r\n" + 
				"        \"accountType\": \"RESIDENTIAL\"\r\n" + 
				"      },\r\n" + 
				"      \"accountStatus\": \"Active\",\r\n" + 
				"      \"languagePreference\": \"ENGLISH\"\r\n" + 
				"    },\r\n" + 
				"    \"users\": [\r\n" + 
				"      {\r\n" + 
				"        \"comcastUserGuid\": \"10000033440\",\r\n" + 
				"        \"firstName\": \"AEQUIPMGMT106\",\r\n" + 
				"        \"lastName\": \"TEST\",\r\n" + 
				"        \"email\": \"ibbfiekgccfjh@gmail.com\",\r\n" + 
				"        \"role\": \"Primary\",\r\n" + 
				"        \"dob\": \"\"\r\n" + 
				"      }\r\n" + 
				"    ]\r\n" + 
				"  }";
				
		AccountInformation accInformation = new Gson().fromJson(accInfo, AccountInformation.class);
		@SuppressWarnings("rawtypes")
		ParameterizedMspResponse parameterizedMspResponse = new ParameterizedMspResponse();
		parameterizedMspResponse.setData(accInformation);
		ResponseEntity<ParameterizedMspResponse<AccountInformation>> accountResponse = new ResponseEntity<ParameterizedMspResponse<AccountInformation>>(parameterizedMspResponse, HttpStatus.OK);
		PowerMockito.when(prospectService.getAccountInformation(accountGuid)).thenReturn(accountResponse);
		// Act
		boolean accountInfoUpdated =ReflectionTestUtils.invokeMethod(orderNotificationService, "populateAccountCancelData", orderCancelledData);
		// Assert
		assertEquals(false, accountInfoUpdated);
	}
	
}