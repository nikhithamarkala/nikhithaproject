package com.comcast.xfinity.mobile.notifications.util;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.comcast.xfinity.mobile.notifications.service.OrderNotificationService;

@PowerMockIgnore({"org.apache.http.conn.ssl.", "javax.net.ssl." , "javax.crypto.*"})
@RunWith(PowerMockRunner.class)
@PrepareForTest(KeyUtil.class)
public class KeyUtilTest {

	private KeyUtil keyUtil;

	@Before
	public void setUp() throws Exception {
		keyUtil = new KeyUtil();
		

	}
	@Test
	public void assertdecryptPropertyValueIsNotEncryptedValue() throws Exception {
		// Arrange
		String key = "wireless-key";
		String propertyValue = "ZF_R393_56th";
		// Act

		String propertyValue1 = keyUtil.decryptPropertyValue(key, propertyValue);

		// Assert
		assertEquals("ZF_R393_56th", propertyValue1);

	}

	@Test
	public void assertdecryptPropertyValueIsEncryptedValue() throws Exception {
		// Arrange
		String key = "wireless-key";
		String propertyValue = "1C1GiDUK3zwW7dB2v7btdRQE56tjAtHB";
		// Act

		String propertyValue1 = keyUtil.decryptPropertyValue(key, propertyValue);

		// Assert
		assertEquals("1C1GiDUK3zwW7dB2v7btdRQE56tjAtHB", propertyValue1);

	}

	@Test
	public void assertencryptPropertyValueIsEncryptedValue() throws Exception {
		// Arrange
		String key = "qzlxBN1BOdnFlOR0QkxZBlddvvT2U/VY";
		String propertyValue = "1C1GiDUK3zwW7dB2v7btdRQE56tjAtHB";
		// Act

		String propertyValue1 = keyUtil.encryptPropertyValue(key, propertyValue);

		// Assert
		assertEquals("ENC", propertyValue1.substring(0, 3));
	}
	
	@Test
	public void assertencryptPropertyValueIsNotEncryptedValue() throws Exception {
		// Arrange
		String key = "4Yp/98kIHnqGgKyA1VMa8gtpQUZRk9qX";
		String propertyValue = "Dx6Rm7Of0q_y";
		// Act

		String propertyValue1 = keyUtil.encryptPropertyValue(key, propertyValue);

		// Assert
		assertEquals("ENC", propertyValue1.substring(0, 3));
	}
}
