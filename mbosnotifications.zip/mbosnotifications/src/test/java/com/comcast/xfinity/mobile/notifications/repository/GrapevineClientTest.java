package com.comcast.xfinity.mobile.notifications.repository;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.comcast.xfinity.mobile.notifications.config.properties.GrapevineProperties;
import com.comcast.xfinity.mobile.notifications.domain.OrderPlacedEventData;
import com.comcast.xfinity.mobile.notifications.domain.OrderStatusChangeEventData;
import com.comcast.xfinity.mobile.notifications.domain.grapevine.MessageParameters;
import com.comcast.xfinity.mobile.notifications.domain.grapevine.OrderCreatedNotification;
import com.comcast.xfinity.mobile.notifications.domain.grapevine.UserContacts;
import com.comcast.xfinity.mobile.notifications.service.remote.ProspectServiceClient;
import com.comcast.xfinity.mobile.utils.logging.model.JsonUtils;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ GrapevineClient.class, JsonUtils.class })
public class GrapevineClientTest {

	@InjectMocks
	private GrapevineClient grapevineClient;
	@Mock
	private CimaTokenRepository cimaClient;
	@Mock
	private GrapevineProperties grapevineProperties;
	@Mock
	UserContacts userContacts;
	@Mock
	BasicRestClient restClient;
	@Mock
	OrderPlacedEventData orderData;
	OrderStatusChangeEventData orderCancelledData;
	OrderCreatedNotification notificationBody;
	MessageParameters messageParams;
	List<String> email = new ArrayList<>();
	List<String> phone = new ArrayList<>();

	Map<String, String> headers = new HashMap<>();
	Map<String, String> parameters = new HashMap<>();

	@Before
	public void setUp() throws Exception {
		orderData = new OrderPlacedEventData();
		orderData.setOrderId("123455");
		orderData.setAccountGuid("");
		orderData.setClientId("");
		orderData.setArterraOrderId("");
		orderData.setOrderTotal("");
		orderData.setOrderType("");
		orderData.setFirstName("");
		orderData.setLastName("");
		orderData.setTimestamp("");
		orderData.setContactPhoneNumbers(phone);
		orderData.setContactEmailAddresses(email);
		orderData.setProductSkus(null);
		orderData.setAvailabilityDescription(null);

		orderCancelledData = new OrderStatusChangeEventData();
		orderCancelledData.setOrderSubmissionDate(null);
		orderCancelledData.setContactEmailId("ibbfiekgccfjh@gmail.com");
		orderCancelledData.setContactPhoneNumber("2111129378");
		orderCancelledData.setFirstName("");
		orderCancelledData.setLastName("");
		orderCancelledData.setTimestamp("2018-08-30T13:47:37.630Z");
		orderCancelledData.setOrderId("123455");
		orderCancelledData.setArterraOrderId(null);
		orderCancelledData.setCustomerGuid(null);
		orderCancelledData.setAccountGuid("49748631195");
		orderCancelledData.setContactPhoneNumbers(phone);
		orderCancelledData.setContactEmailAddresses(email);
		orderCancelledData.setFraudStatus(null);

		headers.put("Content-Type", "application/json");

		userContacts = new UserContacts();
		email.add("ibbfiekgccfjh@gmail.com");
		phone.add("2111129378");
		userContacts.setEmail(email);
		userContacts.setPhone(phone);

		messageParams = new MessageParameters();
		messageParams.setAvailabilityDate("");
		messageParams.setDateOrderSubmitted(null);
		messageParams.setOrderDate(null);
		messageParams.setOrderNumber("123455");
		messageParams.setOrderTotal(null);
		messageParams.setOrderType("");
		messageParams.setPahFirstName("");

		notificationBody = new OrderCreatedNotification();
		notificationBody.setUserContacts(userContacts);
		notificationBody.setMessageParams(messageParams);
		
		grapevineClient = PowerMockito.spy(new GrapevineClient());

		String baseUrl = "http://142.136.162.35:8080";
		Mockito.when(grapevineProperties.getBaseUrl()).thenReturn(baseUrl);
		String notificationEndpoint = "/nc/api/v1.7/notification/user/{notificationID}";
		Mockito.when(grapevineProperties.getNotificationEndpoint()).thenReturn(notificationEndpoint);

		ReflectionTestUtils.setField(grapevineClient, "grapevineProperties", grapevineProperties,
				GrapevineProperties.class);
		ReflectionTestUtils.setField(grapevineClient, "cimaClient", cimaClient, CimaTokenRepository.class);

	}
	
	@Test
	public void assertSendOrderCreateNotification() throws Exception {
		// Arrange
		String serviceUrl = "http://142.136.162.35:8080/nc/api/v1.7/notification/user/ORD-ACK-02";
		String response = "{  \r\n" + "   \"code\":\"NC_90001\",\r\n" + "   \"message\":\"Success\",\r\n"
				+ "   \"moreInfo\":null,\r\n" + "   \"payload\":null,\r\n" + "   \"httpCode\":\"OK\"\r\n" + "}";

		String notificationRequest = "{\"userContacts\":{\"phone\":[\"2111129378\"],\"email\":[\"ibbfiekgccfjh@gmail.com\"]},\"messageParams\":{\"orderNumber\":\"123455\",\"pahFirstName\":\"\",\"orderTotal\":null,\"dateOrderSubmitted\":null,\"orderDate\":null,\"orderType\":\"\",\"availabilityDate\":\"\"}}";

		String templateId = "ORD-ACK-02";
		Mockito.when(grapevineProperties.getOrderCreateNotificationTemplateId()).thenReturn(templateId);
		PowerMockito.doReturn(serviceUrl).when(grapevineClient, "createServiceUrl", Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString());
		PowerMockito.doReturn(notificationBody).when(grapevineClient, "buildOrderCreateNotificationRequest", orderData);
		PowerMockito.stub(PowerMockito.method(JsonUtils.class, "marshal")).toReturn(notificationRequest);
		PowerMockito.doReturn(restClient).when(grapevineClient, "createGrapevineRestClient");
		Mockito.when(restClient.doPost(serviceUrl, notificationRequest, headers, parameters)).thenReturn(response);
		// Act
		String gvResponse = grapevineClient.sendOrderCreateNotification(orderData);
		// Assert
		assertEquals("Success", gvResponse.substring(42, 49));

	}

	@Test
	public void assertsendOrderCancelledNotification() throws Exception {
		// Arrange
		String serviceUrl = "http://142.136.162.35:8080/nc/api/v1.7/notification/user/ORD-CANCEL-01";
		String response = "{  \r\n" + "   \"code\":\"NC_90001\",\r\n" + "   \"message\":\"Success\",\r\n"
				+ "   \"moreInfo\":null,\r\n" + "   \"payload\":null,\r\n" + "   \"httpCode\":\"OK\"\r\n" + "}";

		String templateId = "ORD-CANCEL-01";
		Mockito.when(grapevineProperties.getOrderCancelNotificationTemplateId()).thenReturn(templateId);
		String notificationRequest = "{\"userContacts\":{\"phone\":[\"2111129378\"],\"email\":[\"ibbfiekgccfjh@gmail.com\"]},\"messageParams\":{\"orderNumber\":\"123455\",\"pahFirstName\":\"\",\"orderTotal\":null,\"dateOrderSubmitted\":null,\"orderDate\":null,\"orderType\":\"\",\"availabilityDate\":\"\"}}";
		PowerMockito.doReturn(notificationBody).when(grapevineClient, "buildOrderCancelNotificationRequest",
				orderCancelledData);
		PowerMockito.doReturn(serviceUrl).when(grapevineClient, "createServiceUrl", Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString());
		PowerMockito.stub(PowerMockito.method(JsonUtils.class, "marshal")).toReturn(notificationRequest);
		PowerMockito.doReturn(restClient).when(grapevineClient, "createGrapevineRestClient");
		Mockito.when(restClient.doPost(serviceUrl, notificationRequest, headers, parameters)).thenReturn(response);

		// Act
		String gvResponse = grapevineClient.sendOrderCancelledNotification(orderCancelledData);
		// Assert
		assertEquals("Success", gvResponse.substring(42, 49));

	}
	@Test
	public void assertbuildOrderCreateNotificationRequest() throws Exception {
		//Arrange
		
		//Act
		OrderCreatedNotification notificationBody = ReflectionTestUtils.invokeMethod(grapevineClient, "buildOrderCreateNotificationRequest", orderData);
		
		//Assert
		
		assertEquals("ibbfiekgccfjh@gmail.com", notificationBody.getUserContacts().getEmail().get(0));
		assertEquals("2111129378", notificationBody.getUserContacts().getPhone().get(0));
		
	}
	
	@Test
	public void assertcreateServiceUrl() throws Exception {
		//Arrange
		String baseUrl = "http://142.136.162.35:8080";
		String notificationEndpoint = "/nc/api/v1.7/notification/user/{notificationID}";
		String templateId = "ORD-ACK-02";
		//Act
		String SerUrl = ReflectionTestUtils.invokeMethod(grapevineClient, "createServiceUrl", baseUrl, notificationEndpoint, templateId);
		
		//Assert
		
		assertEquals("http://142.136.162.35:8080/nc/api/v1.7/notification/user/ORD-ACK-02", SerUrl);
		
	}
	
	@Test
	public void assertbuildOrderCancelNotificationRequest() throws Exception {
		//Arrange
		
		//Act
		OrderCreatedNotification notificationBody = ReflectionTestUtils.invokeMethod(grapevineClient, "buildOrderCancelNotificationRequest", orderCancelledData);
		
		//Assert
		
		assertEquals("ibbfiekgccfjh@gmail.com", notificationBody.getUserContacts().getEmail().get(0));
		assertEquals("2111129378", notificationBody.getUserContacts().getPhone().get(0));
		
	}
}
