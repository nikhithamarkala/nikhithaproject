package com.comcast.xfinity.mobile.notifications.web.rest.errors;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Ignore;
import org.springframework.core.MethodParameter;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import com.comcast.xfinity.mobile.notifications.domain.account.AccountInformation;
import com.comcast.xfinity.mobile.notifications.web.rest.errors.ExceptionTranslator;

import org.junit.Test;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;

public class ExceptionTranslatorTest {
	
	private ExceptionTranslator exceptionTranslator;
	 @Before
	public void setup() {
	        exceptionTranslator = PowerMockito.spy(new ExceptionTranslator());
	}
	
    @Test
    public void testprocessValidationError() throws NoSuchMethodException, SecurityException {
        BeanPropertyBindingResult errors = new BeanPropertyBindingResult(new AccountInformation(), "account");
        FieldError fieldError = new FieldError("obj", "field", "defaultMessage");
        errors.addError(fieldError);
        MethodArgumentNotValidException excep = new MethodArgumentNotValidException(new MethodParameter(AccountInformation.class.getDeclaredMethod("getAccountInfo"), 0), errors);
        ErrorVM errorVM = exceptionTranslator.processValidationError(excep);
        assertEquals(errorVM.getMessage(), "error.validation");
    }
    
	@Test
    public void testprocessParameterizedValidationError() {
        CustomParameterizedException excep = new CustomParameterizedException("message");
        ParameterizedErrorVM errorVM = exceptionTranslator.processParameterizedValidationError(excep);
        assertEquals(errorVM.getMessage(), "message");
    }
	
    @Test
    public void testProcessAccessDeniedException() {
        AccessDeniedException excep = new AccessDeniedException("message");
        ErrorVM errorVM = exceptionTranslator.processAccessDeniedException(excep);
        assertEquals(errorVM.getMessage(), "error.accessDenied");
    }
    
    @Test
    public void testProcessMethodNotSupportedException() {
        HttpRequestMethodNotSupportedException excep = new HttpRequestMethodNotSupportedException("method");
        ErrorVM errorVM = exceptionTranslator.processMethodNotSupportedException(excep);
        assertEquals(errorVM.getMessage(), "error.methodNotSupported");
    }
    
    @Test
    public void testProcessRuntimeException() throws Exception {
    	Exception excep = new Exception("message");
        ResponseEntity<ErrorVM> errorVM = exceptionTranslator.processRuntimeException(excep);
        assertEquals(errorVM.getBody().getMessage(), "error.internalServerError");
    }

}
