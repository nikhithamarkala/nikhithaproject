package com.comcast.xfinity.mobile.notifications.config.properties;

public class GrapevineProperties {
    private String baseUrl;
    private String notificationEndpoint;
    private String orderCreateNotificationTemplateId;
    private int connectionTimeout;
    private int socketTimeout;
    private String clientSecret;
    private String clientValue;
    private String orderCancelNotificationTemplateId;
    private String orderFraudNotificationTemplateId;

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String getNotificationEndpoint() {
        return notificationEndpoint;
    }

    public void setNotificationEndpoint(String notificationUrl) {
        this.notificationEndpoint = notificationUrl;
    }

    public String getOrderCreateNotificationTemplateId() {
        return orderCreateNotificationTemplateId;
    }

    public void setOrderCreateNotificationTemplateId(String orderCreateNotificationTemplateId) {
        this.orderCreateNotificationTemplateId = orderCreateNotificationTemplateId;
    }

    public int getConnectionTimeout() {
        return this.connectionTimeout;
    }

    public void setConnectionTimeout(int connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
    }

    public int getSocketTimeout() {
        return socketTimeout;
    }

    public void setSocketTimeout(int socketTimeout) {
        this.socketTimeout = socketTimeout;
    }

    public String getClientSecret() {
        return this.clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    public String getClientValue() {
        return clientValue;
    }

    public void setClientValue(String clientValue) {
        this.clientValue = clientValue;
    }

    public String getOrderCancelNotificationTemplateId() {
        return orderCancelNotificationTemplateId;
    }

    public void setOrderCancelNotificationTemplateId(String orderCancelNotificationTemplateId) {
        this.orderCancelNotificationTemplateId = orderCancelNotificationTemplateId;
    }

    public String getOrderFraudNotificationTemplateId() {
        return orderFraudNotificationTemplateId;
    }

    public void setOrderFraudNotificationTemplateId(String orderFraudNotificationTemplateId) {
        this.orderFraudNotificationTemplateId = orderFraudNotificationTemplateId;
    }

}
