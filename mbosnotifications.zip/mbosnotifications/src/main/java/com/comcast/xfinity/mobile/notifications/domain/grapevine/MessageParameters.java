package com.comcast.xfinity.mobile.notifications.domain.grapevine;

public class MessageParameters{
    private String orderNumber;
    private String pahFirstName;
    private String orderTotal;
    private String dateOrderSubmitted;
    private String orderDate;
    private String orderType;
    private String availabilityDate;
    
    public String getOrderNumber() {
        return orderNumber;
    }
    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }
    public String getPahFirstName() {
        return pahFirstName;
    }
    public void setPahFirstName(String pahFirstName) {
        this.pahFirstName = pahFirstName;
    }
    public String getOrderTotal() {
        return orderTotal;
    }
    public void setOrderTotal(String orderTotal) {
        this.orderTotal = orderTotal;
    }
    public String getDateOrderSubmitted() {
        return dateOrderSubmitted;
    }
    public void setDateOrderSubmitted(String dateOrderSubmitted) {
        this.dateOrderSubmitted = dateOrderSubmitted;
    }
    public String getOrderDate() {
        return orderDate;
    }
    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }
    public String getOrderType() {
        return orderType;
    }
    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }
    public String getAvailabilityDate() {
        return availabilityDate;
    }
    public void setAvailabilityDate(String availabilityDate) {
        this.availabilityDate = availabilityDate;
    }
}