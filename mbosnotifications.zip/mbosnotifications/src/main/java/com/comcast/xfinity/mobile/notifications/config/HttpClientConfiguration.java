package com.comcast.xfinity.mobile.notifications.config;

import javax.inject.Inject;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.comcast.xfinity.mobile.notifications.config.properties.HttpClientProperties;

@Configuration
public class HttpClientConfiguration {

    @Inject
    private HttpClientProperties httpClientProperties;

    /**
     * @return the RetTemplate Object. This method sets the marshaller object as
     *         params to RestTemplate leveraging the marshalling capability to
     *         the template.
     */
    @Bean(name = "restTemplate")
    public RestTemplate getRestTemplate() {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.setRequestFactory(clientHttpRequestFactory());
        return restTemplate;
    }

    @Bean
    @Inject
    public CloseableHttpClient mspHttpClient() {

        return createHttpClient(httpClientProperties);
    }

    private ClientHttpRequestFactory clientHttpRequestFactory() {
        int timeout = 5000;
        RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout).setConnectionRequestTimeout(timeout)
                .setSocketTimeout(timeout).build();
        CloseableHttpClient client = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
        return new HttpComponentsClientHttpRequestFactory(client);
    }

    private CloseableHttpClient createHttpClient(HttpClientProperties httpClientProperties) {

        RequestConfig mspRequestConfig = RequestConfig.custom()
                .setSocketTimeout(httpClientProperties.getSocketTimeout())
                .setConnectTimeout(httpClientProperties.getConnectionTimeout()).build();
        ConnectionSocketFactory sslConnectionSocketFactory = SSLConnectionSocketFactory.getSocketFactory();
        Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                .register("http", PlainConnectionSocketFactory.getSocketFactory())
                .register("https", sslConnectionSocketFactory).build();
        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(registry);
        connectionManager.setDefaultMaxPerRoute(httpClientProperties.getDefaultMaxConnectionsPerHost());
        connectionManager.setMaxTotal(httpClientProperties.getMaxTotalConnections());
        return HttpClientBuilder.create().setConnectionManagerShared(true).setDefaultRequestConfig(mspRequestConfig)
                .setConnectionManager(connectionManager).build();
    }

}
