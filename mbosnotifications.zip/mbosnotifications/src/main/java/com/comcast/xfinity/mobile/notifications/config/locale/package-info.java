/**
 * Locale specific code.
 */
package com.comcast.xfinity.mobile.notifications.config.locale;
