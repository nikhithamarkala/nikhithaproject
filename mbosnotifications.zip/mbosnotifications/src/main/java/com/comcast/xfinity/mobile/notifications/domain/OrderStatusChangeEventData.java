package com.comcast.xfinity.mobile.notifications.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderStatusChangeEventData extends EventData {

    private String orderSubmissionDate;
    private String contactEmailId;
    private String contactPhoneNumber;
    private String firstName;
    private String lastName;
    private String timestamp;
    private String orderId;
    private String arterraOrderId;
    private String customerGuid;
    private String accountGuid;
    private List<String> contactPhoneNumbers;
    private List<String> contactEmailAddresses;
    private FraudStatusType fraudStatus;

    public String getOrderSubmissionDate() {
        return orderSubmissionDate;
    }

    public void setOrderSubmissionDate(String orderSubmissionDate) {
        this.orderSubmissionDate = orderSubmissionDate;
    }

    public String getContactEmailId() {
        return contactEmailId;
    }

    public void setContactEmailId(String contactEmailId) {
        this.contactEmailId = contactEmailId;
    }

    public String getContactPhoneNumber() {
        return contactPhoneNumber;
    }

    public void setContactPhoneNumber(String contactPhoneNumber) {
        this.contactPhoneNumber = contactPhoneNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getCustomerGuid() {
        return customerGuid;
    }

    public void setCustomerGuid(String customerGuid) {
        this.customerGuid = customerGuid;
    }

    public String getAccountGuid() {
        return accountGuid;
    }

    public void setAccountGuid(String accountGuid) {
        this.accountGuid = accountGuid;
    }

    public List<String> getContactPhoneNumbers() {
        return contactPhoneNumbers;
    }

    public void setContactPhoneNumbers(List<String> contactPhoneNumbers) {
        this.contactPhoneNumbers = contactPhoneNumbers;
    }

    public List<String> getContactEmailAddresses() {
        return contactEmailAddresses;
    }

    public void setContactEmailAddresses(List<String> contactEmailAddresses) {
        this.contactEmailAddresses = contactEmailAddresses;
    }

    public String getArterraOrderId() {
        return arterraOrderId;
    }

    public void setArterraOrderId(String arterraOrderId) {
        this.arterraOrderId = arterraOrderId;
    }

    public FraudStatusType getFraudStatus() {
        return fraudStatus;
    }

    public void setFraudStatus(FraudStatusType fraudStatus) {
        this.fraudStatus = fraudStatus;
    }

}
