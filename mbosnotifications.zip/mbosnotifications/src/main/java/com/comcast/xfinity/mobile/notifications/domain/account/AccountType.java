package com.comcast.xfinity.mobile.notifications.domain.account;

public enum AccountType {
    COMMERCIAL,
    RESIDENTIAL
}