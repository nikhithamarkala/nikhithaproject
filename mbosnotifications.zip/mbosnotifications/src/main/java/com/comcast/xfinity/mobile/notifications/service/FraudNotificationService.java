package com.comcast.xfinity.mobile.notifications.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.comcast.xfinity.mobile.notifications.domain.FraudOrderEventData;
import com.comcast.xfinity.mobile.notifications.repository.MerlotClient;

@Service
public class FraudNotificationService {
    private static final Logger LOGGER = LoggerFactory.getLogger(FraudNotificationService.class);

    @Autowired
    private MerlotClient merlotClient;

    public void sendFraudOrderNotification(final FraudOrderEventData fraudOrderData) {
    	LOGGER.debug("Inside FraudNotificationService.sendFraudOrderNotification() method.");
        String merlotResponse = merlotClient.logFraudOrderTicket(fraudOrderData);
        LOGGER.debug("Merlot Response: {}", merlotResponse);
    }
}
