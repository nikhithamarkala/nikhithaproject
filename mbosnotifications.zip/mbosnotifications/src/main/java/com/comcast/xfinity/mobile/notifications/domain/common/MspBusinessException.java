package com.comcast.xfinity.mobile.notifications.domain.common;

public class MspBusinessException extends RuntimeException {

 /**
     * 
     */
    private static final long serialVersionUID = 6440599634383501525L;
    private ErrorCode errorCode;
    
   

    public MspBusinessException(ErrorCode errorCode) {
        super();
        this.errorCode = errorCode;
    }

    public MspBusinessException(ErrorCode errorCode, String message, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        
    }

    public MspBusinessException(ErrorCode errorCode,String message) {
        super(message);
        this.errorCode = errorCode;
    }

    public MspBusinessException(ErrorCode errorCode,Throwable cause) {
        super(cause);
        this.errorCode = errorCode;
    }
    
    public ErrorCode getErrorCode() {
        return errorCode;
    }
    
    protected void setErrorCode(ErrorCode errorCode) {
        this.errorCode = errorCode;
    }
    
}
