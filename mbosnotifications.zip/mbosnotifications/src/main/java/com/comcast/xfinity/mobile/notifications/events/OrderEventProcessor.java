package com.comcast.xfinity.mobile.notifications.events;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.comcast.xfinity.mobile.notifications.domain.OrderStatusChangeEventData;
import com.comcast.xfinity.mobile.notifications.domain.FraudStatusType;
import com.comcast.xfinity.mobile.notifications.domain.OrderEvent;
import com.comcast.xfinity.mobile.notifications.domain.OrderPlacedEventData;
import com.comcast.xfinity.mobile.notifications.service.OrderNotificationService;
import com.comcast.xfinity.mobile.util.logging.LogAction;

@EnableBinding(MbosEventChannel.class)
public class OrderEventProcessor {

    private static final Logger LOGGER = LoggerFactory.getLogger(OrderEventProcessor.class);

    @Autowired
    private OrderNotificationService orderNotificationService;

    @LogAction(actionPerformed = "processOrderEvent", path = "OrderEventProcessor", parameterNames = "orderEvent")
    @StreamListener(MbosEventChannel.ORDER_EVENT_CHANNEL)
    public void processOrderEvent(OrderEvent orderEvent) {
        LOGGER.debug("Received order event");

        switch (orderEvent.getEventType()) {
        case ORDER_PLACED:
            OrderPlacedEventData orderCreateData = (OrderPlacedEventData) orderEvent.getPayload();
            orderNotificationService.sendOrderPlacedNotification(orderCreateData);
            break;

        case ORDER_CANCELED:
            final OrderStatusChangeEventData orderCancelledEventData = (OrderStatusChangeEventData) orderEvent.getPayload();
            if (orderCancelledEventData.getFraudStatus() != FraudStatusType.REVIEW_CANCELED) {
                orderNotificationService.sendOrderCancelledNotification(orderCancelledEventData);
            }
            break;

        default:
            LOGGER.debug(String.format("Received order event type %s", orderEvent.getEventType()));
            break;
        }
    }
}
