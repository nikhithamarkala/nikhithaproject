package com.comcast.xfinity.mobile.notifications.domain.account;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "User", description = "User resource representation")
public class User {
    @ApiModelProperty(value = "Comcast User Guid", required = true)
    private String comcastUserGuid;

    @ApiModelProperty(value = "User's First Name", required = true)
    private String firstName;

    @ApiModelProperty(value = "User's Last Name", required = true)
    private String lastName;

    @ApiModelProperty(value = "User's Email", required = true)
    private String email;

    @ApiModelProperty(value = "Role", required = true)
    private Role role;

    @ApiModelProperty(value = "Date of Birth (MM/DD/YYYY)", required = true)
    private String dob;

    public User() {
        super();
        this.comcastUserGuid = null;
        this.firstName = null;
        this.lastName = null;
        this.role = null;
        this.email = null;
        this.dob = null;
    }

    public User(String comcastUserGuid, String firstName, String lastName, Role role, String email, String dob) {
        super();
        this.comcastUserGuid = comcastUserGuid;
        this.firstName = firstName;
        this.lastName = lastName;
        this.role = role;
        this.email = email;
        this.dob = dob;
    }

    public String getComcastUserGuid() {
        return comcastUserGuid;
    }

    public void setComcastUserGuid(String comcastUserGuid) {
        this.comcastUserGuid = comcastUserGuid;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }


    @Override
    public String toString() {

        StringBuilder friendlyStr = new StringBuilder();
        friendlyStr.append("User [comcastUserGuid=");
        friendlyStr.append(this.getComcastUserGuid() == null ? null : this.getComcastUserGuid());
        friendlyStr.append(", firstName=");
        friendlyStr.append(this.getFirstName() == null ? null : this.getFirstName());
        friendlyStr.append(", lastName=");
        friendlyStr.append(this.getLastName() == null ? null : this.getLastName());
        friendlyStr.append(", role=");
        friendlyStr.append(this.getRole() == null ? null : this.getRole());
        friendlyStr.append(", email=");
        friendlyStr.append(this.getEmail() == null ? null : this.getEmail());
        friendlyStr.append(", dob=");
        friendlyStr.append(this.getDob() == null ? null : this.getDob());
        friendlyStr.append("]");

        return friendlyStr.toString();
    }
}
