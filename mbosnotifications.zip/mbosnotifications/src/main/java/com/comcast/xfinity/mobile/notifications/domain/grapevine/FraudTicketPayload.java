package com.comcast.xfinity.mobile.notifications.domain.grapevine;

public class FraudTicketPayload {
    private String orderType;
    private String modestoAccountNumber;
    private String comcastAccountNumber;
    private String mspOrderId;
    private String firstName;
    private String lastName;
    private String timestamp;
    private String fraudScore;
    private String contactEmailId;
    private String contactPhoneNumber;
    private String fraudReason;
    private String orderCreationDate;
    private String productSkus;

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getModestoAccountNumber() {
        return modestoAccountNumber;
    }

    public void setModestoAccountNumber(String modestoAccountNumber) {
        this.modestoAccountNumber = modestoAccountNumber;
    }

    public String getComcastAccountNumber() {
        return comcastAccountNumber;
    }

    public void setComcastAccountNumber(String comcastAccountNumber) {
        this.comcastAccountNumber = comcastAccountNumber;
    }

    public String getMspOrderId() {
        return mspOrderId;
    }

    public void setMspOrderId(String mspOrderId) {
        this.mspOrderId = mspOrderId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getFraudScore() {
        return fraudScore;
    }

    public void setFraudScore(String fraudScore) {
        this.fraudScore = fraudScore;
    }

    public String getContactEmailId() {
        return contactEmailId;
    }

    public void setContactEmailId(String contactEmailId) {
        this.contactEmailId = contactEmailId;
    }

    public String getContactPhoneNumber() {
        return contactPhoneNumber;
    }

    public void setContactPhoneNumber(String contactPhoneNumber) {
        this.contactPhoneNumber = contactPhoneNumber;
    }

    public String getFraudReason() {
        return fraudReason;
    }

    public void setFraudReason(String fraudReason) {
        this.fraudReason = fraudReason;
    }

    public String getOrderCreationDate() {
        return orderCreationDate;
    }

    public void setOrderCreationDate(String orderCreationDate) {
        this.orderCreationDate = orderCreationDate;
    }

    public String getProductSkus() {
        return productSkus;
    }

    public void setProductSkus(String productSkus) {
        this.productSkus = productSkus;
    }

}
