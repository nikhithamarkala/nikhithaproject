package com.comcast.xfinity.mobile.notifications.domain;

public enum FraudStatusType {
    NONE(0), PENDING_REVIEW(1), REVIEW_CANCELED(2), REVIEW_CLEARED(3), CLEARED(4);

    private Integer fraudStatusCode = 0;

    FraudStatusType(Integer fraudStatusCode) {
        this.fraudStatusCode = fraudStatusCode;
    }

    public Integer getFraudStatusTypeCode() {
        return fraudStatusCode;
    }

}
