/**
 * JPA domain objects.
 */
package com.comcast.xfinity.mobile.notifications.domain;
