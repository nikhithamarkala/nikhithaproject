package com.comcast.xfinity.mobile.notifications.domain.common;

import java.util.EnumMap;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@XmlRootElement
@XmlType(propOrder = { "code", "message" })
public class ErrorDescription {
    private static EnumMap<ErrorCode, String> errorMessages = new EnumMap<ErrorCode, String>(ErrorCode.class);
    private ErrorCode code;
    private String message;

    static {
        errorMessages.put(ErrorCode.NotImplemented, "Functionality has not been implemented.");
        errorMessages.put(ErrorCode.NoSuchNumber, "Number does not exist.");
        errorMessages.put(ErrorCode.MalformedNumber, "Malformed number.");
        errorMessages.put(ErrorCode.MalformedEnum, "Incorrect value supplied for an enum.");
        errorMessages.put(ErrorCode.NumberReservationFailed, "An error occurred attempting to reserve a number.");
        errorMessages.put(ErrorCode.NumberReleaseFailed, "An error occurred attempting to release a number.");
        errorMessages.put(ErrorCode.NumberStatusIncorrect, "Incorrect CTN number status.");
        errorMessages.put(ErrorCode.LineStatusIncorrect, "Incorrect Line status.");
        errorMessages.put(ErrorCode.LineIdExists, "Line ID is not unique.");
        errorMessages.put(ErrorCode.AccountIdExists, "Account ID is not unique.");
        errorMessages.put(ErrorCode.LineAddFailed, "An error occurred attempting to add Line.");
        errorMessages.put(ErrorCode.TrackingCodeAddFailed, "An error occurred attempting to add Tracking code.");
        errorMessages.put(ErrorCode.LineUpdateFailed, "An error occurred attempting to update Line.");
        errorMessages.put(ErrorCode.AccountStatusIncorrect, "Incorrect Account status.");
        errorMessages.put(ErrorCode.NoSuchLine, "Line does not exist.");
        errorMessages.put(ErrorCode.NoSuchDevice, "Device does not exist.");
        errorMessages.put(ErrorCode.NoSuchSimCard, "Sim card does not exist.");
        errorMessages.put(ErrorCode.MalformedLineId, "A malformed line id was provided.");
        errorMessages.put(ErrorCode.MalformedDeviceId, "A malformed device id was provided.");
        errorMessages.put(ErrorCode.AttributesNotAllowed, "Some attributes found in the request are not allowed.");
        errorMessages.put(ErrorCode.AttributesMissing, "Some attribute(s) in the request are missing.");
        errorMessages.put(ErrorCode.XfinityWiFiProvisioningFailed, "An error occurred attempting to provision/unprovision Xfinity wifi for a line.");
        errorMessages.put(ErrorCode.IMSProvisioningFailed, "An error occurred attempting to provision/unprovision IMS service for a line.");
        errorMessages.put(ErrorCode.InternalError, "An internal error occurred.");
        errorMessages.put(ErrorCode.RokeUpdateFailed, "An error occurred attempting to update Roke.");
        errorMessages.put(ErrorCode.NoSuchAccount, "Account does not exist.");
        errorMessages.put(ErrorCode.MalformedAccountGuid, "A malformed account guid was provided.");
        errorMessages.put(ErrorCode.MalformedAccessToken, "A malformed access token was provided.");
        errorMessages.put(ErrorCode.NoSuchCustomerGuid, "Customer guid does not exist.");
        errorMessages.put(ErrorCode.NoSuchAccountGuid, "Account guid does not exist.");
        errorMessages.put(ErrorCode.CarrierSearchServiceCallFailed, "An error occurred attempting to Search Carrier.");
        errorMessages.put(ErrorCode.MalformedCredentials, "A malformed account guid/customer guid was provided.");
        errorMessages.put(ErrorCode.NoSuchAddress, "Incorrect Address.");
        errorMessages.put(ErrorCode.VoicemailBoxCreateFailed, "An error occurred attempting to create a Voicemail box");
        errorMessages.put(ErrorCode.VoicemailBoxDeleteFailed, "An error occurred attempting to delete a Voicemail box");
        errorMessages.put(ErrorCode.VoicemailBoxRestoreFailed, "An error occurred attempting to restore a Voicemail box");
        errorMessages.put(ErrorCode.InvalidMdn, "Invalid MDN format.");
        errorMessages.put(ErrorCode.AAAProvisioningFailed, "An error occurred attempting to provision/unprovision AAA service for a line.");
        errorMessages.put(ErrorCode.ESDRepositoryCallFailed, "An error occurred attempting to call ESD Service");
        errorMessages.put(ErrorCode.ESDRepositoryAddLOBFailed, "An error occurred while adding new LOB with ESD Service");
        errorMessages.put(ErrorCode.ESDRepositoryDeactivateLOBFailed, "An error occurred while deactivating LOB with ESD Service");
        errorMessages.put(ErrorCode.ESDRepositorySuspendLOBFailed, "An error occurred while suspending LOB with ESD Service");
        errorMessages.put(ErrorCode.ESDRepositoryCreateLineFailed, "An error occurred while creating new Line with ESD Service");
        errorMessages.put(ErrorCode.ESDRepositoryDeactiveLineFailed, "An error occurred while deactivating Line with ESD Service");
        errorMessages.put(ErrorCode.ESDRepositorySuspendLineFailed, "An error occurred while suspending Line with ESD Service");
        errorMessages.put(ErrorCode.BearerTokenCallFailed, "An error occurred attempting to call bearer token service");
        errorMessages.put(ErrorCode.FE001, "Missing Date of Birth.");
        errorMessages.put(ErrorCode.FE002, "Missing Last 4 of SSN.");
        errorMessages.put(ErrorCode.FE003, "User does not exist.");
        errorMessages.put(ErrorCode.FE004, "Fraud.");
        errorMessages.put(ErrorCode.FE005, "Address does not match.");
        errorMessages.put(ErrorCode.NoSuchCustomer, "Customer does not exist.");
        errorMessages.put(ErrorCode.AccountUpdateFailed, "An error occurred attempting to update Account.");
        errorMessages.put(ErrorCode.CSPRepositoryException, "An error occurred in CSP Service.");
        errorMessages.put(ErrorCode.ErrorInPolicyService, "An error occurred in the Policy Service.");
        errorMessages.put(ErrorCode.MissingPolicyServiceParameters, "Both IMEI and IMSI required for call to Policy Server.");
        errorMessages.put(ErrorCode.EncryptFailure, "An error Occurred in Encryption.");
        errorMessages.put(ErrorCode.MDNExists, "MDN already exist");
        errorMessages.put(ErrorCode.DatabaseException, "An error occurred in attempting Database call.");
        errorMessages.put(ErrorCode.CustomerCareServiceException, "Customer Care Service Exception.");
        errorMessages.put(ErrorCode.NoLinesFound, "No Line(s) Found.");
        errorMessages.put(ErrorCode.BillingRepositoryAddCallFailed, "An error occurred while adding rate code with OMS service");
        errorMessages.put(ErrorCode.BillingRepositoryRemoveCallFailed, "An error occurred while removing rate code with OMS service");
        errorMessages.put(ErrorCode.AAARepositoryFailureInDeregister, "AAASessionService unable to Deregister");
        errorMessages.put(ErrorCode.IdentityCredentialServiceException, "An error occurred in IdentityCredential Service.");
        errorMessages.put(ErrorCode.ATTRouteRepositoryUpdateFailed, "An error occurred updating ATTRoute Service.");
        errorMessages.put(ErrorCode.ATTRouteRepositoryCallException, "An error occurred in attempting to call ATTRoute Service.");
        errorMessages.put(ErrorCode.LocationServiceException, "An error occurred in Location Service.");
        errorMessages.put(ErrorCode.NotANumber, " Id should be a Number.");
        errorMessages.put(ErrorCode.PolicyServerBusy, "Policy Server Busy.");
        errorMessages.put(ErrorCode.PolicyServiceIncorrectCredentials, "Policy Service incorrect_credentials - missing, unknown, or invalid credentials");
        errorMessages.put(ErrorCode.PolicyServiceMissingRequiredFields, "Policy Service required fields device_id malformed, (e.g. missing IMSI or IMEI/MEID)");
        errorMessages.put(ErrorCode.PolicyServiceNetworkError, "Policy Service network type error -  missing or invalid network type.");
        errorMessages.put(ErrorCode.PolicyServiceRequestError, "Policy Service request string contains JSON/XML reserved characters");
        errorMessages.put(ErrorCode.AAARepositoryExceptionInDeregister, "AAASessionService Exception in Deregister.");
        errorMessages.put(ErrorCode.IDAnalyticsException, "ID Analytics Exception.");
        errorMessages.put(ErrorCode.BuyFlowStateSaveFailed, "An error occurred while saving BuyFlow state.");
        errorMessages.put(ErrorCode.InternalCreditCheckServiceFailed, "An error occurred in Internal Credit Check Service.");
        errorMessages.put(ErrorCode.CallbackServiceException, "An error occured in CallAgent WaitTime Service.");
        errorMessages.put(ErrorCode.CallbackAddFailed, "An error occured during adding Callback");
        errorMessages.put(ErrorCode.NoSuchCallbackIdFound, "No Such CallbackId Found");
        errorMessages.put(ErrorCode.NoExistingCallbacks, "Unable to find the existing Callbacks");
        errorMessages.put(ErrorCode.ExternalCreditCheckServiceFailed, "An error occurred in External Credit Check Service.");
        errorMessages.put(ErrorCode.LineServiceException, "An error occurred in Line Service.");
        errorMessages.put(ErrorCode.InvalidInputFields, "Invalid Input Fields");
        errorMessages.put(ErrorCode.ProspectAddFailed, "An error occurred attempting to add Prospect.");
        errorMessages.put(ErrorCode.InvalidInputFields, "Invalid Input Fields");
        errorMessages.put(ErrorCode.DTAttributePopulationFailed, "Degital turbine activation for exisiting devices failed.");
        errorMessages.put(ErrorCode.NoExistingDeviceFound, "There is no existing device(s) found for this line.");
        errorMessages.put(ErrorCode.VoicemailBoxRetrieveFailed, "An error occurred attempting to get voicemailbox details");
        errorMessages.put(ErrorCode.LegalAgeVerificationServiceFailed, "An error occurred in the Legal Age Verification Service");
        errorMessages.put(ErrorCode.OrderManagementService, "Order Management Service Exception");
        errorMessages.put(ErrorCode.INVALID_URL_CONFIGURED, "An error occurred in the while processing the request. Please reach out to msp-support.");
        errorMessages.put(ErrorCode.UNABLE_TO_CONNECT_TO_REMOTE_HOST, "An error occurred in the while processing the request. Please reach out to msp-support.");
        errorMessages.put(ErrorCode.GENERIC_SYSTEM_ERROR, "An error occurred in the while processing the request. Please reach out to msp-support.");
        errorMessages.put(ErrorCode.UNABLE_TO_GET_CIMA_TOKEN_FOR_GRAPEVINE, "An error occurred in the while processing the request. Please reach out to msp-support.");
    }

    // Constructors
    public ErrorDescription() {
        super();
        this.code = null;
        this.message = null;
    }

    public ErrorDescription(ErrorCode code) {
        super();
        this.code = code;
        this.message = errorMessages.get(code);
    }

    // Getters and Setters
    public ErrorCode getCode() {
        return code;
    }

    public void setCode(ErrorCode code) {
        this.code = code;
        this.message = errorMessages.get(code);
    }

    public String getMessage() {
        return message;
    }

    public static String getMessage(ErrorCode code) {
        return errorMessages.get(code);
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }
}
