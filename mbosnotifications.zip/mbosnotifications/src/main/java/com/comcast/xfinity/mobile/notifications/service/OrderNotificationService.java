package com.comcast.xfinity.mobile.notifications.service;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.comcast.xfinity.mobile.notifications.domain.OrderStatusChangeEventData;
import com.comcast.xfinity.mobile.notifications.domain.OrderPlacedEventData;
import com.comcast.xfinity.mobile.notifications.domain.account.AccountInformation;
import com.comcast.xfinity.mobile.notifications.domain.account.Role;
import com.comcast.xfinity.mobile.notifications.domain.common.ParameterizedMspResponse;
import com.comcast.xfinity.mobile.notifications.repository.GrapevineClient;
import com.comcast.xfinity.mobile.notifications.service.remote.ProspectServiceClient;

@Service
public class OrderNotificationService {
    private static final Logger LOGGER = LoggerFactory.getLogger(OrderNotificationService.class);

    @Autowired
    private GrapevineClient grapevineClient;

    @Autowired
    private ProspectServiceClient prospectService;

    public String sendOrderPlacedNotification(OrderPlacedEventData orderData) {
        boolean accountInfoUpdated = populateAccountData(orderData);
        LOGGER.debug("Account data population status: {}", accountInfoUpdated);
        String response = grapevineClient.sendOrderCreateNotification(orderData);
        LOGGER.debug("Notification NC Response: {}", response);
        return response;

    }

    public String sendOrderCancelledNotification(OrderStatusChangeEventData orderCancelledData) {
        boolean accountInfoUpdated = populateAccountCancelData(orderCancelledData);
        LOGGER.debug("Account data population status: {}", accountInfoUpdated);
        String response = grapevineClient.sendOrderCancelledNotification(orderCancelledData);
        LOGGER.debug("Notification NC Response: {}", response);
        return response;
    }

    private boolean populateAccountData(OrderPlacedEventData orderData) {
        boolean accountInfoUpdated = false;
        String accountGuid = orderData.getAccountGuid();
        try {
            ResponseEntity<ParameterizedMspResponse<AccountInformation>> accountResponse = prospectService.getAccountInformation(accountGuid);
            if (accountResponse != null && accountResponse.getBody() != null && accountResponse.getBody().getData() != null) {
                AccountInformation accountInformation = accountResponse.getBody().getData();
                String accountNumber = accountInformation.getAccountInfo().getComcastAccountNumber();
                LOGGER.debug("The comcast account number for account guid {} is {}", accountGuid, accountNumber);
                if (accountInformation.getUsers() != null) {
                    accountInformation.getUsers().forEach(user -> {
                        if (user.getRole().equals(Role.Primary)) {
                            LOGGER.debug("Found Primary user with with guid: {} for accountGuid: {}", user.getComcastUserGuid(), accountGuid);
                            if (StringUtils.isNotBlank(user.getEmail())) {
                                String email = user.getEmail().toLowerCase();
                                if (!orderData.getContactEmailAddresses().contains(email)) {
                                    orderData.getContactEmailAddresses().add(email);
                                }
                            }

                        }
                    });
                }
                accountInfoUpdated = true;
            } else {
                LOGGER.warn("Unable to get the account information from prospect service. Response is : {}", accountResponse);
            }
        } catch (Exception e) {
            LOGGER.warn("Exception while fetching account information. Notification is being attempted using information from order.", e);

        }
        return accountInfoUpdated;
    }

    private boolean populateAccountCancelData(OrderStatusChangeEventData orderCancelData) {
        boolean accountInfoUpdated = false;
        String accountGuid = orderCancelData.getAccountGuid();
        try {
            if (StringUtils.isNotBlank(orderCancelData.getContactEmailId())) {
                orderCancelData.getContactEmailAddresses().add(orderCancelData.getContactEmailId());
            }
            if (StringUtils.isNotBlank(orderCancelData.getContactPhoneNumber())) {
                orderCancelData.getContactPhoneNumbers().add(orderCancelData.getContactPhoneNumber());
            }
            ResponseEntity<ParameterizedMspResponse<AccountInformation>> accountResponse = prospectService.getAccountInformation(accountGuid);
            if (accountResponse != null && accountResponse.getBody() != null && accountResponse.getBody().getData() != null) {
                AccountInformation accountInformation = accountResponse.getBody().getData();
                String accountNumber = accountInformation.getAccountInfo().getComcastAccountNumber();
                LOGGER.debug("The comcast account number for account guid {} is {}", accountGuid, accountNumber);
                if (accountInformation.getUsers() != null) {
                    accountInformation.getUsers().forEach(user -> {
                        if (user.getRole().equals(Role.Primary)) {
                            LOGGER.debug("Found Primary user with with guid: {} for accountGuid: {}", user.getComcastUserGuid(), accountGuid);
                            if (StringUtils.isNotBlank(user.getEmail())) {
                                String email = user.getEmail().toLowerCase();
                                if (!orderCancelData.getContactEmailAddresses().contains(email)) {
                                    orderCancelData.getContactEmailAddresses().add(email);
                                }
                            }

                        }
                    });
                }
                accountInfoUpdated = true;
            } else {
                LOGGER.warn("Unable to get the account information from prospect service. Response is : {}", accountResponse);
            }
        } catch (Exception e) {
            LOGGER.warn("Exception while fetching account information. Notification is being attempted using information from order.", e);

        }
        return accountInfoUpdated;
    }
}
