package com.comcast.xfinity.mobile.notifications.config;

import javax.inject.Inject;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import feign.RequestInterceptor;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Configuration
public class FeignClientConfiguration {

    @Inject
    private JHipsterProperties properties;

    @Bean
    public RequestInterceptor requestTokenBearerInterceptor() {
        return requestTemplate -> {
            String token = Jwts.builder().setSubject("admin").claim("auth", "admin").signWith(SignatureAlgorithm.HS512, properties.getSecurity().getAuthentication().getJwt().getSecret()).compact();
            requestTemplate.header("Authorization", "Bearer " + token);
        };
    }
}
