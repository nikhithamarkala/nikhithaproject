package com.comcast.xfinity.mobile.notifications.events;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.comcast.xfinity.mobile.notifications.domain.FraudOrderEventData;
import com.comcast.xfinity.mobile.notifications.domain.MbosEventType;
import com.comcast.xfinity.mobile.notifications.domain.OrderEvent;
import com.comcast.xfinity.mobile.notifications.service.FraudNotificationService;
import com.comcast.xfinity.mobile.util.logging.LogAction;

@EnableBinding(MbosEventChannel.class)
public class FraudEventProcessor {
    private static final Logger LOGGER = LoggerFactory.getLogger(FraudEventProcessor.class);

    @Autowired
    private FraudNotificationService fraudNotificationService;

    @LogAction(actionPerformed = "processFraudOrderEvent", path = "FraudEventProcessor", parameterNames = "orderEvent")
    @StreamListener(MbosEventChannel.FRAUD_EVENT_CHANNEL)
    public void processFraudOrderEvent(OrderEvent orderEvent) {
        LOGGER.debug("Received fraud order event");
        if (orderEvent.getEventType().equals(MbosEventType.FRAUD_DETECTED)) {
        	LOGGER.debug("Inside If of Order event type.");
            final FraudOrderEventData orderFraudEventData = (FraudOrderEventData) orderEvent.getPayload();
            fraudNotificationService.sendFraudOrderNotification(orderFraudEventData);
        }
    }
}
