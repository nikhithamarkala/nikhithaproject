package com.comcast.xfinity.mobile.notifications.domain.account;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "Address", description = "Address resource representation")
public class CustomerInformationAddress {
	@ApiModelProperty(value = "Address Line 1", required = true)
	private String address1;

	@ApiModelProperty(value = "Address Line 2", required = false)
	private String address2;

	@ApiModelProperty(value = "City", required = false)
	private String city;

	@ApiModelProperty(value = "State", required = false)
	private String state;

	@ApiModelProperty(value = "Zipcode", required = true)
	private String zip;

	@ApiModelProperty(value = "Latitude of the Account’s address", required = false)
	private String latitude;

	@ApiModelProperty(value = "Longitude of the Account’s address", required = false)
	private String longitude;

	@ApiModelProperty(value = "Account Type", required = true)
	
	private AccountType accountType;

	public CustomerInformationAddress() {
		super();
		this.address1 = null;
		this.address2 = null;
		this.city = null;
		this.state = null;
		this.zip = null;
		this.latitude = null;
		this.longitude = null;
		this.accountType = null;
	}

	public CustomerInformationAddress(String address1, String address2, String city, String state, String zip,
			String latitude, String longitude, AccountType accountType) {
		super();
		this.address1 = address1;
		this.address2 = address2;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.latitude = latitude;
		this.longitude = longitude;
		this.accountType = accountType;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public AccountType getAccountType() {
		return accountType;
	}

	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	@Override
	public String toString() {

		StringBuilder friendlyStr = new StringBuilder();
		friendlyStr.append("Address [address1=");
		friendlyStr.append(this.getAddress1() == null ? null : this.getAddress1());
		friendlyStr.append(", address2=");
		friendlyStr.append(this.getAddress2() == null ? null : this.getAddress2());
		friendlyStr.append(", city=");
		friendlyStr.append(this.getCity() == null ? null : this.getCity());
		friendlyStr.append(", state=");
		friendlyStr.append(this.getState() == null ? null : this.getState());
		friendlyStr.append(", zip=");
		friendlyStr.append(this.getZip() == null ? null : this.getZip());
		friendlyStr.append(", latitude=");
		friendlyStr.append(this.getLatitude() == null ? null : this.getLatitude());
		friendlyStr.append(", longitude=");
		friendlyStr.append(this.getLongitude() == null ? null : this.getLongitude());
		friendlyStr.append(", accountType=");
		friendlyStr.append(this.getAccountType() == null ? null : this.getAccountType());
		friendlyStr.append("]");

		return friendlyStr.toString();
	}
}
