package com.comcast.xfinity.mobile.notifications.repository;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.comcast.xfinity.mobile.notifications.config.properties.EncryptionProperties;
import com.comcast.xfinity.mobile.notifications.config.properties.GrapevineProperties;
import com.comcast.xfinity.mobile.notifications.config.properties.NotificationProperties;
import com.comcast.xfinity.mobile.notifications.domain.cima.CimaTokenResponse;
import com.comcast.xfinity.mobile.notifications.domain.common.ErrorCode;
import com.comcast.xfinity.mobile.notifications.domain.common.MspBusinessException;
import com.comcast.xfinity.mobile.notifications.domain.common.ServiceException;
import com.comcast.xfinity.mobile.notifications.domain.common.ServiceException.Type;
import com.comcast.xfinity.mobile.notifications.util.KeyUtil;
import com.comcast.xfinity.mobile.utils.logging.model.JsonUtils;

@Component
public class CimaTokenRepository {
    final static Logger logger = LoggerFactory.getLogger(CimaTokenRepository.class);

    private static final String GRANT_TYPE = "grant_type";
    private static String BEARER_TOKEN;
    private static long EXPIRATION;
    private static final String CLIENT_HEADER = "client";

    @Inject
    private NotificationProperties notificationProperties;
    
    @Inject
    private GrapevineProperties grapevineProperties;

    @Inject
    private KeyUtil keyUtil;

    @Inject
    private EncryptionProperties encryptionProperties;

    /**
     * Gets the current bearer token for OAuth2.0 authorization
     *
     * @return the bearer token
     */
    public String getBearerToken() {
        synchronized (CimaTokenRepository.class) {
            if (isTokenExpired()) {
                try {
                    refreshToken();
                } catch (ServiceException e) {
                    throw new MspBusinessException(ErrorCode.UNABLE_TO_GET_CIMA_TOKEN_FOR_GRAPEVINE, e);
                }
            }
            return BEARER_TOKEN;
        }
    }

    /*
     * Checks to see if the current bearer token is expired.
     */
    private boolean isTokenExpired() {
        if (StringUtils.isNotEmpty(BEARER_TOKEN)) {
            if (System.currentTimeMillis() < EXPIRATION) {
                return false;
            }
        }
        return true;
    }

    /*
     * Refreshes current token and expiration.
     */
    private void refreshToken() throws ServiceException {
        String cimaUrl = notificationProperties.getCimaUrl();
        String requestBodyContent = "";
        Map<String, String> headers = new HashMap<>();

        BasicRestClient cimaTokenClient = createCimaBasicTokenRestClient();
        Map<String, String> params = new HashMap<>();
        params.put(GRANT_TYPE, "client_credentials");
        String response;
        try {
            response = cimaTokenClient.doPost(cimaUrl, requestBodyContent, headers, params);
        } catch (Exception e) {
            throw new ServiceException(e, Type.CIMA_TOKEN);
        }

        if (StringUtils.isNotBlank(response)) {
            CimaTokenResponse json;
            try {
                json = JsonUtils.unmarshallJson(response, CimaTokenResponse.class);
            } catch (Exception e) {
                throw new RuntimeException("Unable to get the CIMA Token for calling CSP", e);
            }
            if (null != json) {
                BEARER_TOKEN = json.getAccessToken();
                EXPIRATION = System.currentTimeMillis() + Long.valueOf(json.getExpiresIn());
            } else {
                logger.error("JSON response is null, token was not refreshed correctly");
                throw new MspBusinessException(ErrorCode.GENERIC_SYSTEM_ERROR,
                        "Unable to obtain the cima token for calling CSP");

            }
        }

    }

    @Lookup
    protected BasicRestClient createBasicRestClient() {
        // This implementation will be overridden by spring.
        return null;
    }

    private BasicRestClient createCimaBasicTokenRestClient() {

        String cimaClientSecret = keyUtil.decryptPropertyValue(encryptionProperties.getKey(),
                grapevineProperties.getClientSecret());
        int connectionTimeout = grapevineProperties.getConnectionTimeout();
        int socketTimeout = grapevineProperties.getSocketTimeout();

        HashMap<String, Object> headers = new HashMap<>();
        headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED);
        headers.put(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON);
        headers.put(CLIENT_HEADER, grapevineProperties.getClientValue());
        BasicRestClient restClient = createBasicRestClient();
        restClient.setBearerAuth(false);
        restClient.setHeaders(headers);
        restClient.setConsumerSecret(cimaClientSecret);
        restClient.setConnectionTimeout(Integer.toString(connectionTimeout));
        restClient.setSocketTimeout(Integer.toString(socketTimeout));
        return restClient;
    }

}
