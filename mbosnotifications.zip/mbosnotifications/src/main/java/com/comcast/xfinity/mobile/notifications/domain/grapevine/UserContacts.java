package com.comcast.xfinity.mobile.notifications.domain.grapevine;

import java.util.ArrayList;
import java.util.List;

public class UserContacts {

    private List<String> phone;

    private List<String> email;
    
    

    public UserContacts() {
        super();
        phone = new ArrayList<>();
        email = new ArrayList<>();
        
    }

    public List<String> getPhone() {
        return phone;
    }

    public void setPhone(List<String> phone) {
        this.phone = phone;
    }

    public List<String> getEmail() {
        return email;
    }

    public void setEmail(List<String> email) {
        this.email = email;
    }

}
