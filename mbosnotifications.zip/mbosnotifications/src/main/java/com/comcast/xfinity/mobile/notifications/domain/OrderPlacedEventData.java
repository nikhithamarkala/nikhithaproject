package com.comcast.xfinity.mobile.notifications.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Event data for {@link MbosEventType#ORDER_PLACED} events.
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class OrderPlacedEventData extends EventData {
    
    private String clientId;
    private String accountGuid;
    private String arterraOrderId;
    private String orderId;
    private String orderTotal;
    private String orderType;
    private String firstName;
    private String lastName;
    private String timestamp;
    private List<String> contactPhoneNumbers;
    private List<String> contactEmailAddresses;
    private List<String> productSkus;
    private String availabilityDescription;

    public List<String> getProductSkus() {
        return productSkus;
    }

    public void setProductSkus(List<String> productSkus) {
        this.productSkus = productSkus;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderTotal() {
        return orderTotal;
    }

    public void setOrderTotal(String orderTotal) {
        this.orderTotal = orderTotal;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public List<String> getContactPhoneNumbers() {
        return contactPhoneNumbers;
    }

    public void setContactPhoneNumbers(List<String> contactPhoneNumbers) {
        this.contactPhoneNumbers = contactPhoneNumbers;
    }

    public List<String> getContactEmailAddresses() {
        return contactEmailAddresses;
    }

    public void setContactEmailAddresses(List<String> contactEmailAddresses) {
        this.contactEmailAddresses = contactEmailAddresses;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getAccountGuid() {
        return accountGuid;
    }

    public void setAccountGuid(String accountGuid) {
        this.accountGuid = accountGuid;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getArterraOrderId() {
        return arterraOrderId;
    }

    public void setArterraOrderId(String arterraOrderId) {
        this.arterraOrderId = arterraOrderId;
    }

    public String getAvailabilityDescription() {
        return availabilityDescription;
    }

    public void setAvailabilityDescription(String availabilityDescription) {
        this.availabilityDescription = availabilityDescription;
    }
}
