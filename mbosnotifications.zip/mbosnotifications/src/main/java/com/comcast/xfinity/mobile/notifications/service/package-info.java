/**
 * Service layer beans.
 */
package com.comcast.xfinity.mobile.notifications.service;
