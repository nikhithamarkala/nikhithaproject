package com.comcast.xfinity.mobile.notifications.domain;

public enum MbosEventType {
    ORDER_PLACED, ORDER_SUBMITTED,FRAUD_DETECTED, ORDER_CANCELED, ORDER_UPDATED
}
