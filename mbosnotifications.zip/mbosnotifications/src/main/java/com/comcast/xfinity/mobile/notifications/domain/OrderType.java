package com.comcast.xfinity.mobile.notifications.domain;

public enum OrderType {
    REGULAR, PREORDER, BACKORDER;

    
}
