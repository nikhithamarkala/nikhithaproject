package com.comcast.xfinity.mobile.notifications.domain.common;

public class NoSuchAccountException extends MspBusinessException {
    /**
     * 
     */
    private static final long serialVersionUID = 3307041971726054928L;
    
    

    public NoSuchAccountException() {
        super(ErrorCode.NoSuchAccount);
    }

    public NoSuchAccountException( String message, Throwable cause) {
        super(ErrorCode.NoSuchAccount,message, cause);
        
    }

    public NoSuchAccountException(String message) {
        super(ErrorCode.NoSuchAccount,message);
       
    }
    
}
