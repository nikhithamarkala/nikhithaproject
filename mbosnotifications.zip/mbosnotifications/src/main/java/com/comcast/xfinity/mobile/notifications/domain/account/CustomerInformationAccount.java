package com.comcast.xfinity.mobile.notifications.domain.account;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerInformationAccount {
	@ApiModelProperty(value = "Account GUID", required = true)
	private String accountGuid;

	@ApiModelProperty(value = "Comcast Account Number", required = true)
	private String comcastAccountNumber;

	@ApiModelProperty(value = "First Name", required = true)
	private String firstName;

	@ApiModelProperty(value = "Last Name", required = true)
	private String lastName;

	@ApiModelProperty(value = "SSN", notes = "last 4", required = true)
	private String ssn;

	@ApiModelProperty(value = "Employee Flag", required = true)
	private boolean isEmployee;

	@ApiModelProperty(value = "Service Address", required = true)
	private CustomerInformationAddress serviceAddress;

	@ApiModelProperty(value = "Billing Address", required = true)
	private CustomerInformationAddress billingAddress;

	@ApiModelProperty(value = "Account Status", required = true)
	private String accountStatus;

	@ApiModelProperty(value = "Language Preference", required = true)
	private String languagePreference;

	public CustomerInformationAccount() {
		super();
		this.accountGuid = null;
		this.comcastAccountNumber = null;
		this.firstName = null;
		this.lastName = null;
		this.ssn = null;
		this.serviceAddress = null;
		this.isEmployee = false;
	}

	public CustomerInformationAccount(String accountGuid, String comcastAccountNumber, String firstName,
			String lastName, String ssn, CustomerInformationAddress serviceAddress, boolean isEmployee) {
		super();
		this.accountGuid = accountGuid;
		this.comcastAccountNumber = comcastAccountNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.ssn = ssn;
		this.serviceAddress = serviceAddress;
		this.isEmployee = isEmployee;
	}

	public CustomerInformationAccount(String accountGuid, String comcastAccountNumber, String firstName,
			String lastName, String ssn, boolean isEmployee, CustomerInformationAddress serviceAddress,
			CustomerInformationAddress billingAddress, String accountStatus, String languagePreference) {
		super();
		this.accountGuid = accountGuid;
		this.comcastAccountNumber = comcastAccountNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.ssn = ssn;
		this.isEmployee = isEmployee;
		this.serviceAddress = serviceAddress;
		this.billingAddress = billingAddress;
		this.accountStatus = accountStatus;
		this.languagePreference = languagePreference;
	}

	public String getAccountGuid() {
		return accountGuid;
	}

	public void setAccountGuid(String accountGuid) {
		this.accountGuid = accountGuid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public CustomerInformationAddress getServiceAddress() {
		return serviceAddress;
	}

	public void setServiceAddress(CustomerInformationAddress serviceAddress) {
		this.serviceAddress = serviceAddress;
	}

	public CustomerInformationAddress getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(CustomerInformationAddress billingAddress) {
		this.billingAddress = billingAddress;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public String getLanguagePreference() {
		return languagePreference;
	}

	public void setLanguagePreference(String languagePreference) {
		this.languagePreference = languagePreference;
	}

	public void setEmployee(boolean isEmployee) {
		this.isEmployee = isEmployee;
	}

	public String getComcastAccountNumber() {
		return comcastAccountNumber;
	}

	public void setComcastAccountNumber(String comcastAccountNumber) {
		this.comcastAccountNumber = comcastAccountNumber;
	}

	public boolean getIsEmployee() {
		return isEmployee;
	}

	public void setIsEmployee(boolean isEmployee) {
		this.isEmployee = isEmployee;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
