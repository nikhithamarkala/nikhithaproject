package com.comcast.xfinity.mobile.notifications.config;

import javax.inject.Inject;

import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.comcast.xfinity.mobile.notifications.config.properties.EncryptionProperties;
import com.comcast.xfinity.mobile.notifications.config.properties.GrapevineProperties;
import com.comcast.xfinity.mobile.notifications.config.properties.HttpClientProperties;
import com.comcast.xfinity.mobile.notifications.config.properties.MerlotProperties;
import com.comcast.xfinity.mobile.notifications.config.properties.NotificationProperties;

@RefreshScope
@Configuration
public class NotificationPropertiesConfiguration {

    @Inject
    private NotificationProperties notificationProperties;
    

    
    public NotificationProperties getNotificationProperties() {
        return notificationProperties;
    }

    public void setNotificationProperties(NotificationProperties notificationProperties) {
        this.notificationProperties = notificationProperties;
    }

    
    @Bean
    public EncryptionProperties encryptionProperties() {
        return notificationProperties.getEncryption();
    }

    @Bean
    public GrapevineProperties grapevineProperties() {
        return notificationProperties.getGrapevineProperties();
    }

    @Bean
    public HttpClientProperties httpClientProperties() {
        return notificationProperties.getHttpClient();
    }
    
    @Bean
    public MerlotProperties merlotProperties() {
        return notificationProperties.getMerlotProperties();
    }
}
