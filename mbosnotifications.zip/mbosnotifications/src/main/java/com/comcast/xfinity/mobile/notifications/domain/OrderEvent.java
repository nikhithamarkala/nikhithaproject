package com.comcast.xfinity.mobile.notifications.domain;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class OrderEvent implements Serializable{
    
    /**
     * 
     */
    private static final long serialVersionUID = -8397738608725757777L;
    
    private String eventId;
    private MbosEventType eventType;
    private EventData payload;
    private String timestamp;
    
    public String getEventId() {
        return eventId;
    }
    public void setEventId(String eventId) {
        this.eventId = eventId;
    }
    public MbosEventType getEventType() {
        return eventType;
    }
    public void setEventType(MbosEventType eventType) {
        this.eventType = eventType;
    }
    public EventData getPayload() {
        return payload;
    }
    public void setPayload(EventData payload) {
        this.payload = payload;
    }
    public String getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);

    }

}
