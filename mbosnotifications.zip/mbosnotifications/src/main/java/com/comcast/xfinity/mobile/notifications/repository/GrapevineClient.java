package com.comcast.xfinity.mobile.notifications.repository;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.text.StrSubstitutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Repository;

import com.comcast.xfinity.mobile.notifications.config.properties.GrapevineProperties;
import com.comcast.xfinity.mobile.notifications.domain.OrderPlacedEventData;
import com.comcast.xfinity.mobile.notifications.domain.OrderStatusChangeEventData;
import com.comcast.xfinity.mobile.notifications.domain.OrderType;
import com.comcast.xfinity.mobile.notifications.domain.grapevine.MessageParameters;
import com.comcast.xfinity.mobile.notifications.domain.grapevine.OrderCreatedNotification;
import com.comcast.xfinity.mobile.notifications.domain.grapevine.UserContacts;
import com.comcast.xfinity.mobile.util.logging.LogAction;
import com.comcast.xfinity.mobile.utils.logging.model.JsonUtils;

@RefreshScope
@Repository
public class GrapevineClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(GrapevineClient.class);

    private static final String CLIENT_HEADER = "client";

    @Inject
    private CimaTokenRepository cimaClient;

    @Inject
    private GrapevineProperties grapevineProperties;

    @LogAction(actionPerformed = "sendOrderCreateNotification", parameterNames = { "orderData" }, path = "GrapevineClient")
    public String sendOrderCreateNotification(OrderPlacedEventData orderData) {
        String baseUrl = grapevineProperties.getBaseUrl();
        String notificationEndpoint = grapevineProperties.getNotificationEndpoint();
        String templateId = grapevineProperties.getOrderCreateNotificationTemplateId();

        String serviceUrl = createServiceUrl(baseUrl, notificationEndpoint, templateId);
        OrderCreatedNotification notificationBody = buildOrderCreateNotificationRequest(orderData);
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        Map<String, String> parameters = new HashMap<>();
        String notificationRequest = JsonUtils.marshal(notificationBody);
        String response = createGrapevineRestClient().doPost(serviceUrl, notificationRequest, headers, parameters);

        LOGGER.debug("Grapevine Response {}", response);
        return response;
    }

    @LogAction(actionPerformed = "sendOrderCancelledNotification", parameterNames = { "orderCancelledData" }, path = "GrapevineClient")
    public String sendOrderCancelledNotification(OrderStatusChangeEventData orderCancelledData) {
        String baseUrl = grapevineProperties.getBaseUrl();
        String notificationEndpoint = grapevineProperties.getNotificationEndpoint();
        String templateId = grapevineProperties.getOrderCancelNotificationTemplateId();

        String serviceUrl = createServiceUrl(baseUrl, notificationEndpoint, templateId);
        OrderCreatedNotification notificationBody = buildOrderCancelNotificationRequest(orderCancelledData);
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        Map<String, String> parameters = new HashMap<>();
        String notificationRequest = JsonUtils.marshal(notificationBody);
        String response = createGrapevineRestClient().doPost(serviceUrl, notificationRequest, headers, parameters);

        LOGGER.debug("Grapevine Response {}", response);
        return response;
    }

    @Lookup
    protected BasicRestClient createBasicRestClient() {
        // This implementation will be overridden by spring.
        return null;
    }

    private OrderCreatedNotification buildOrderCreateNotificationRequest(OrderPlacedEventData orderData) {
        OrderCreatedNotification notificationBody = new OrderCreatedNotification();

        MessageParameters messageParams = new MessageParameters();
        String orderNumber;
        if(orderData.getOrderType()!=null && orderData.getOrderType().equals(OrderType.REGULAR.name())){
            //Keeping the change backward compatible
            orderNumber=StringUtils.isNotBlank(orderData.getArterraOrderId())?orderData.getArterraOrderId():orderData.getOrderId();
        }else{
            orderNumber=orderData.getOrderId();
        }
        messageParams.setOrderNumber(orderNumber);
        messageParams.setPahFirstName(orderData.getFirstName());
        String availabilityDescription = orderData.getAvailabilityDescription() == null ? "" : orderData.getAvailabilityDescription();
        messageParams.setAvailabilityDate(availabilityDescription);
        messageParams.setOrderType(orderData.getOrderType());
        notificationBody.setMessageParams(messageParams);

        UserContacts userContacts = new UserContacts();
        orderData.getContactEmailAddresses().forEach(email -> {
            if (!userContacts.getEmail().contains(email.toLowerCase())) {
                userContacts.getEmail().add(email.toLowerCase());
            }
        });
        orderData.getContactPhoneNumbers().forEach(phone -> userContacts.getPhone().add(phone));
        notificationBody.setUserContacts(userContacts);
        return notificationBody;
    }

    private String createServiceUrl(String baseUrl, String notificationEndpoint, String templateId) {
        Map<String, String> valuesMap = new HashMap<String, String>();
        valuesMap.put("notificationID", templateId);
        String urlTemplateString = baseUrl + notificationEndpoint;
        StrSubstitutor substitutor = new StrSubstitutor(valuesMap, "{", "}");
        return substitutor.replace(urlTemplateString);
    }

    private BasicRestClient createGrapevineRestClient() {

        int connectionTimeout = grapevineProperties.getConnectionTimeout();
        int socketTimeout = grapevineProperties.getSocketTimeout();

        HashMap<String, Object> headers = new HashMap<>();
        headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
        headers.put(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON);
        BasicRestClient restClient = createBasicRestClient();
        restClient.setHeaders(headers);
        restClient.setConnectionTimeout(Integer.toString(connectionTimeout));
        restClient.setSocketTimeout(Integer.toString(socketTimeout));
        return restClient;
    }

    private OrderCreatedNotification buildOrderCancelNotificationRequest(OrderStatusChangeEventData orderData) {
        OrderCreatedNotification notificationBody = new OrderCreatedNotification();

        MessageParameters messageParams = new MessageParameters();
        messageParams.setOrderNumber(orderData.getOrderId());
        messageParams.setOrderDate(orderData.getOrderSubmissionDate());
        messageParams.setPahFirstName(orderData.getFirstName());
        notificationBody.setMessageParams(messageParams);

        UserContacts userContacts = new UserContacts();
        orderData.getContactEmailAddresses().forEach(email -> {
            if (!userContacts.getEmail().contains(email.toLowerCase())) {
                userContacts.getEmail().add(email.toLowerCase());
            }
        });
        orderData.getContactPhoneNumbers().forEach(phone -> userContacts.getPhone().add(phone));
        notificationBody.setUserContacts(userContacts);
        return notificationBody;
    }

}
