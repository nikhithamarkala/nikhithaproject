package com.comcast.xfinity.mobile.notifications.domain.common;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.BAD_REQUEST)
public class MspValidationException extends MspBusinessException {

    /**
     * 
     */
    private static final long serialVersionUID = -6918856710666945926L;

    
    public MspValidationException(ErrorCode errorCode) {
        super(errorCode);
        
    }

   
}
