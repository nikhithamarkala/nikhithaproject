/**
 * Spring Data JPA repositories.
 */
package com.comcast.xfinity.mobile.notifications.repository;
