package com.comcast.xfinity.mobile.notifications.domain.grapevine;

public class OrderCreatedNotification {
    
    private UserContacts userContacts;
    
    private MessageParameters messageParams;
    
    
    
    public UserContacts getUserContacts() {
        return userContacts;
    }


    public void setUserContacts(UserContacts userContacts) {
        this.userContacts = userContacts;
    }


    public MessageParameters getMessageParams() {
        return messageParams;
    }


    public void setMessageParams(MessageParameters messageParams) {
        this.messageParams = messageParams;
    }


    
}




