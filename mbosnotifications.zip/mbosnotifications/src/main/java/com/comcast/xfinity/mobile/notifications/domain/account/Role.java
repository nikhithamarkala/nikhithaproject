package com.comcast.xfinity.mobile.notifications.domain.account;

public enum Role {
    Primary,
    Manager,
    Secondary
}
