package com.comcast.xfinity.mobile.notifications.domain.common;

public enum ErrorCode {
    NotImplemented, NoSuchNumber, MalformedNumber, MalformedEnum, NumberReservationFailed, NumberReleaseFailed, NumberStatusIncorrect, LineAddFailed, LineUpdateFailed, LineIdExists, LineStatusIncorrect, AccountStatusIncorrect, NoSuchLine, NoSuchDevice, NoSuchSimCard, MalformedLineId, MalformedDeviceId, AttributesNotAllowed, AttributesMissing, XfinityWiFiProvisioningFailed, IMSProvisioningFailed, InternalError, RokeUpdateFailed, TrackingCodeAddFailed, NoSuchAccount, AccountIdExists, AccountUpdateFailed, NoSuchAddress, EncryptFailure, MDNExists, NoLinesFound, NotANumber, LineServiceException,
    // getGUIDs
    NoSuchAccountNumber, MalformedCustomerGuid, NoSuchAccountGuid, NoSuchCustomerGuid,
    // eligibility
    MalformedCredentials, MalformedAccessToken,
    // customer information
    MalformedAccountGuid,
    // warnings
    AccountAddFailed, AccountStatusNotActive, NoHSDService, NotAnAppropriateRole, BalancePassedDue, AccountTypeNotResidential,
    // credit check
    NoSuchCustomer,
    // neustar
    CarrierSearchServiceCallFailed,
    // vvm
    VoicemailBoxCreateFailed, InvalidMdn, VoicemailBoxDeleteFailed, VoicemailBoxRestoreFailed, VoicemailBoxRetrieveFailed,
    // aaa
    AAAProvisioningFailed, AAARepositoryFailureInDeregister, CSPRepositoryException, ErrorInPolicyService, MissingPolicyServiceParameters, AAARepositoryExceptionInDeregister,
    // CustomerCareServiceProperties
    CustomerCareServiceException,
    // Database exception
    DatabaseException,

    // ESD
    ESDRepositoryCallFailed, ESDRepositoryAddLOBFailed, ESDRepositoryDeactivateLOBFailed, ESDRepositorySuspendLOBFailed, ESDRepositoryCreateLineFailed, ESDRepositoryDeactiveLineFailed, ESDRepositorySuspendLineFailed,
    // IAndCService
    IdentityCredentialServiceException,
    // BearerTokenClient
    BearerTokenCallFailed,
    // locationServiceException
    LocationServiceException,
    // BillingRepository
    BillingRepositoryAddCallFailed, BillingRepositoryRemoveCallFailed,
    // fraud
    FE001, FE002, FE003, FE004, FE005,
    // ATT Route
    ATTRouteRepositoryUpdateFailed, ATTRouteRepositoryCallException, PolicyServiceMissingRequiredFields, PolicyServiceIncorrectCredentials, PolicyServiceRequestError, PolicyServiceNetworkError, PolicyServerBusy,
    // BuyFlow
    BuyFlowStateSaveFailed,
    // IDSP Analytics
    IDAnalyticsException, InvalidInputFields,
    // ILC
    InternalCreditCheckServiceFailed,
    // CallAgentWaitTimeServiecException
    CallbackServiceException, CallbackAddFailed, NoSuchCallbackIdFound, NoExistingCallbacks,
    // ECC
    ExternalCreditCheckServiceFailed,
    // Legal age verification
    LegalAgeVerificationServiceFailed,
    // Prospect
    ProspectAddFailed,
    // DT Activation
    DTAttributePopulationFailed, NoExistingDeviceFound,
    // OMS
    OrderManagementService,
    //Agent Account Verify
    NoSuchComcastAccountNumber, AgentVerifyServiceException, MalformedVerfiyRequest, UNABLE_TO_GET_CIMA_TOKEN_FOR_GRAPEVINE,
    //Generic System Level Errors
    INVALID_URL_CONFIGURED, UNABLE_TO_CONNECT_TO_REMOTE_HOST, GENERIC_SYSTEM_ERROR
;
}