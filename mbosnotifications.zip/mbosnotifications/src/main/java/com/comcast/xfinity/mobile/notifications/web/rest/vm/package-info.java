/**
 * View Models used by Spring MVC REST controllers.
 */
package com.comcast.xfinity.mobile.notifications.web.rest.vm;
