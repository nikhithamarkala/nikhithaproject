package com.comcast.xfinity.mobile.notifications.config.properties;

public class MerlotProperties {
    private String baseUrl;
    private String merlotEndpoint;
    private String ticketCategory;
    private int connectionTimeout;
    private int socketTimeout;
    private String clientValue;

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String getMerlotEndpoint() {
        return merlotEndpoint;
    }

    public void setMerlotEndpoint(String merlotEndpoint) {
        this.merlotEndpoint = merlotEndpoint;
    }

    public String getTicketCategory() {
        return ticketCategory;
    }

    public void setTicketCategory(String ticketCategory) {
        this.ticketCategory = ticketCategory;
    }

    public int getConnectionTimeout() {
        return connectionTimeout;
    }

    public void setConnectionTimeout(int connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
    }

    public int getSocketTimeout() {
        return socketTimeout;
    }

    public void setSocketTimeout(int socketTimeout) {
        this.socketTimeout = socketTimeout;
    }

    public String getClientValue() {
        return clientValue;
    }

    public void setClientValue(String clientValue) {
        this.clientValue = clientValue;
    }
}
