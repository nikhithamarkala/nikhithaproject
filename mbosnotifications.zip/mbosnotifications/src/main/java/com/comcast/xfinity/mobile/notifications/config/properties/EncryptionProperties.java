package com.comcast.xfinity.mobile.notifications.config.properties;

public class EncryptionProperties {
    private String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
