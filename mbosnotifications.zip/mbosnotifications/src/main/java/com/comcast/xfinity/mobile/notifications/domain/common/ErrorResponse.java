package com.comcast.xfinity.mobile.notifications.domain.common;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class ErrorResponse {

    public static ResponseEntity<MspResponse> getResponse(Exception e) {
        ErrorCode code = ErrorCode.valueOf(e.getMessage());
        ErrorDescription errorDes = new ErrorDescription(code);
        MspResponse mspResponse = new MspResponse(errorDes);

        if (code.equals(ErrorCode.DatabaseException) || code.equals(ErrorCode.IdentityCredentialServiceException)) {
            return new ResponseEntity<>(mspResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        if (code.equals(ErrorCode.AttributesMissing) || code.equals(ErrorCode.LineUpdateFailed) || code.equals(ErrorCode.InvalidMdn) || code.equals(ErrorCode.CSPRepositoryException) || code.equals(ErrorCode.CustomerCareServiceException)) {
            return new ResponseEntity<>(mspResponse, HttpStatus.BAD_REQUEST);
        }

        if (code.equals(ErrorCode.LineIdExists) || code.equals(ErrorCode.MDNExists)) {
            return new ResponseEntity<>(mspResponse, HttpStatus.CONFLICT);
        }

        if (code.equals(ErrorCode.NoSuchAccount) || code.equals(ErrorCode.NoSuchSimCard) || code.equals(ErrorCode.NoSuchLine) || code.equals(ErrorCode.NoSuchAccountGuid) || code.equals(ErrorCode.NoSuchDevice)
                || code.equals(ErrorCode.NoLinesFound) || code.equals(ErrorCode.NoSuchCustomer) || code.equals(ErrorCode.CustomerCareServiceException) || code.equals(ErrorCode.NoSuchCustomerGuid)
                || code.equals(ErrorCode.NoSuchAccountNumber)) {
            return new ResponseEntity<>(mspResponse, HttpStatus.NOT_FOUND);
        }
        
        return null;
    }

}
