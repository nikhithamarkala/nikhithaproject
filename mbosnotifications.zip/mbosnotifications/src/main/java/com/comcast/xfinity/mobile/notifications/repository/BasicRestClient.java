package com.comcast.xfinity.mobile.notifications.repository;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.Configurable;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.osgi.framework.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.comcast.xfinity.mobile.notifications.domain.common.ErrorCode;
import com.comcast.xfinity.mobile.notifications.domain.common.MspBusinessException;
import com.comcast.xfinity.mobile.util.logging.LogAction;

@Component("basicRestClient")
public class BasicRestClient {
    final static Logger LOGGER = LoggerFactory.getLogger(BasicRestClient.class);

    private static final String HTTP_CONNECTION_TIMEOUT = "http.connection.timeout";
    private static final String HTTP_SOCKET_TIMEOUT = "http.socket.timeout";
    private static final String AUTHORIZATION_HEADER = "Authorization";
    private static final String BASIC_AUTH = "Basic";
    private static final String BEARER_AUTH = "Bearer";

    private String consumerSecret = "";
    private String serviceUrl;
    private String socketTimeout = "5000";
    private String connectionTimeout = "2000";
    private String userAgent;
    private HashMap<String, Object> headers;
    private boolean bearerAuth;

    @Inject
    private CloseableHttpClient mspHttpClient;

    public BasicRestClient() {

        consumerSecret = "";
        setServiceUrl("");
        setSocketTimeout("");
        setConnectionTimeout("");
        userAgent = "";
        headers = new HashMap<String, Object>();
    }

    public String getConsumerSecret() {
        return consumerSecret;
    }

    public void setConsumerSecret(String consumerSecret) {
        this.consumerSecret = consumerSecret;
    }

    public String getServiceUrl() {
        return serviceUrl;
    }

    public void setServiceUrl(String serviceUrl) {
        this.serviceUrl = serviceUrl;
    }

    public String getSocketTimeout() {
        return socketTimeout;
    }

    public void setSocketTimeout(String socketTimeout) {
        this.socketTimeout = socketTimeout;
    }

    public String getConnectionTimeout() {
        return connectionTimeout;
    }

    public void setConnectionTimeout(String connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    public HashMap<String, Object> getHeaders() {
        return headers;
    }

    public void setHeaders(HashMap<String, Object> headers) {
        this.headers = headers;
    }

    public String headerValue() {
        Date now = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,sss");
        StringBuffer sb = new StringBuffer();
        sb.append((new StringBuilder()).append(";timestamp=").append(sdf.format(now)).toString());
        return sb.toString();
    }

    /**
     * Do get.
     *
     * @return the string
     *
     * @throws Exception
     *             the exception
     */
    public String doGet(String url) throws Exception {
        String message = "";
        CloseableHttpResponse response = null;
        HttpGet httpGetRequest = buildHttpGetRequest(url);

        try {

            // Configure request-specific settings
            configureRequest(httpGetRequest);

            response = mspHttpClient.execute(httpGetRequest, HttpClientContext.create());
            message = extractMessageFromResponseEntity(response).trim();
            if (response.getStatusLine().getStatusCode() == 450) {
                throw new Exception("Incorrect user parameters: " + message);
            } else if (response.getStatusLine().getStatusCode() == 404) {
                throw new Exception("Subscriber not Found: " + message);
            } else if (response.getStatusLine().getStatusCode() == 401) {
                throw new Exception("User is not assigned to this number: " + message);
            } else if (response.getStatusLine().getStatusCode() >= 500) {
                throw new Exception("Error contacting service: " + message);
            } else if (response.getStatusLine().getStatusCode() >= 400) {
                throw new Exception("Bad Request: " + message);
            }
        } catch (Exception e) {
            LOGGER.error("Exception at doGet ", e);
            throw new Exception(e);
        } finally {
            if (response != null) {
                response.close();
            }
            httpGetRequest.releaseConnection();
        }
        return message;
    }

    public String doPost(String url, String content, Map<String, String> headers, Map<String, String> parameters)
            throws ServiceException {
    	LOGGER.debug("Inside doPost BasicRest Client.");
        HttpPost httpPostRequest;
        HttpEntity stringEntity;
        try {
            httpPostRequest = buildHttpPostRequest(url, headers, parameters);
            stringEntity = new StringEntity((new StringBuilder()).append(content).toString());
        } catch (URISyntaxException e) {
            throw new MspBusinessException(ErrorCode.INVALID_URL_CONFIGURED, e);
        } catch (UnsupportedEncodingException e) {
            throw new MspBusinessException(ErrorCode.INVALID_URL_CONFIGURED, e);
        }
        httpPostRequest.setEntity(stringEntity);
        String message = null;
        CloseableHttpResponse response = null;
        // Configure request-specific settings
        configureRequest(httpPostRequest);
        try {
            response = mspHttpClient.execute(httpPostRequest, HttpClientContext.create());
            if (response!=null) {
                message = extractMessageFromResponseEntity(response).trim();
                if (response.getStatusLine().getStatusCode() >= 400) {
                    throw new ServiceException("Error while contacting service: " + message,
                            response.getStatusLine().getStatusCode());
                }
            }

        } catch (ClientProtocolException e) {
        	LOGGER.error("ClientProtocolException: ", e.getMessage());
            throw new MspBusinessException(ErrorCode.UNABLE_TO_CONNECT_TO_REMOTE_HOST, e);
        } catch (IOException e) {
        	LOGGER.error("IOException: ", e.getMessage());
            throw new MspBusinessException(ErrorCode.UNABLE_TO_CONNECT_TO_REMOTE_HOST, e);
        } finally {
            if (response != null) {
                try {
                    response.close();
                } catch (IOException e) {
                    LOGGER.warn("Unable to close response object",e);
                }
            }
            httpPostRequest.releaseConnection();
        }
        
        return message;
    }

    private void configureRequest(HttpRequestBase httpRequest) {
        RequestConfig.Builder configBuilder = RequestConfig.copy(((Configurable) mspHttpClient).getConfig());
        if (StringUtils.isNumeric(getConnectionTimeout())) {
            configBuilder.setConnectTimeout(Integer.parseInt(getConnectionTimeout()));
        }
        if (StringUtils.isNumeric(getSocketTimeout())) {
            configBuilder.setSocketTimeout(Integer.parseInt(getSocketTimeout()));
        }
        httpRequest.setConfig(configBuilder.build());
    }

    private String extractMessageFromResponseEntity(HttpResponse response) throws IOException {
        String message = "";
        if (response.getEntity() != null) {
            HttpEntity entity = response.getEntity();
            message = EntityUtils.toString(entity);
        }
        return message;
    }

    private HttpGet buildHttpGetRequest(String url) throws URISyntaxException {
        URIBuilder builder = new URIBuilder(url);
        builder.setParameter(HTTP_SOCKET_TIMEOUT, getSocketTimeout()).setParameter(HTTP_CONNECTION_TIMEOUT,
                getConnectionTimeout());
        HttpGet httpGetRequest = new HttpGet(builder.build());
        httpGetRequest.addHeader(AUTHORIZATION_HEADER, getAuthHeaderValue());
        for (Map.Entry<String, Object> entry : headers.entrySet()) {
            httpGetRequest.addHeader(entry.getKey(), entry.getValue().toString());
        }
        return httpGetRequest;
    }

    private HttpPost buildHttpPostRequest(String url, Map<String, String> headers, Map<String, String> paramters)
            throws URISyntaxException {
        URIBuilder builder = new URIBuilder(url);
        builder.setParameter(HTTP_SOCKET_TIMEOUT, getSocketTimeout()).setParameter(HTTP_CONNECTION_TIMEOUT,
                getConnectionTimeout());
        if (paramters != null) {
            for (Map.Entry<String, String> param : paramters.entrySet()) {
                builder.addParameter(param.getKey(), param.getValue());
            }
        }
        HttpPost httpPostRequest = new HttpPost(builder.build());
        httpPostRequest.addHeader(AUTHORIZATION_HEADER, getAuthHeaderValue());
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            httpPostRequest.addHeader(entry.getKey(), entry.getValue());
        }

        return httpPostRequest;
    }

    private String getAuthHeaderValue() {
        if (isBearerAuth()) {
            return getBearerAuthHeaderValue();
        } else {
            return getBasicAuthHeaderValue();
        }
    }

    private String getBasicAuthHeaderValue() {
        String basicAuthHeaderValue = BASIC_AUTH + " " + getConsumerSecret();
        return basicAuthHeaderValue;
    }

    private String getBearerAuthHeaderValue() {
        String basicAuthHeaderValue = BEARER_AUTH + " " + getConsumerSecret();
        return basicAuthHeaderValue;
    }

    public boolean isBearerAuth() {
        return bearerAuth;
    }

    public void setBearerAuth(boolean bearerAuth) {
        this.bearerAuth = bearerAuth;
    }

}
