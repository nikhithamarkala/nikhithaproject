package com.comcast.xfinity.mobile.notifications.repository;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang.text.StrSubstitutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Repository;

import com.comcast.xfinity.mobile.notifications.config.properties.MerlotProperties;
import com.comcast.xfinity.mobile.notifications.domain.FraudOrderEventData;
import com.comcast.xfinity.mobile.notifications.domain.grapevine.FraudTicketPayload;
import com.comcast.xfinity.mobile.util.logging.LogAction;
import com.comcast.xfinity.mobile.utils.logging.model.JsonUtils;

@RefreshScope
@Repository
public class MerlotClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(MerlotClient.class);
    private static final String CLIENT_HEADER = "client";

    @Inject
    private MerlotProperties merlotProperties;

    @Inject
    private CimaTokenRepository cimaClient;

    @LogAction(actionPerformed = "logFraudOrderTicket", parameterNames = { "fraudOrderData" }, path = "MerlotClient")
    public String logFraudOrderTicket(FraudOrderEventData fraudOrderData) {
    	LOGGER.debug("Inside MerlotClient.logFraudOrderTicket() method.");
        String baseUrl = merlotProperties.getBaseUrl();
        String merlotEndpoint = merlotProperties.getMerlotEndpoint();
        String ticketCategory = merlotProperties.getTicketCategory();

        String serviceUrl = createServiceUrl(baseUrl, merlotEndpoint, ticketCategory);
        FraudTicketPayload ticketBody = buildMerlotTicketRequest(fraudOrderData);
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        Map<String, String> parameters = new HashMap<>();
        String merlotTicketRequest = JsonUtils.marshal(ticketBody);
        String response = createMerlotRestClient().doPost(serviceUrl, merlotTicketRequest, headers, parameters);

        LOGGER.debug("Merlot Response {}", response);
        return response;
    }

    private FraudTicketPayload buildMerlotTicketRequest(FraudOrderEventData orderData) {
        FraudTicketPayload fraudTicketPayload = new FraudTicketPayload();
        fraudTicketPayload.setProductSkus(orderData.getProductSkus().toString());
        fraudTicketPayload.setOrderType(orderData.getOrderType());
        fraudTicketPayload.setModestoAccountNumber(orderData.getModestoAccountNumber());
        fraudTicketPayload.setComcastAccountNumber(orderData.getComcastAccountNumber());
        fraudTicketPayload.setMspOrderId(orderData.getMspOrderId());
        fraudTicketPayload.setFirstName(orderData.getFirstName());
        fraudTicketPayload.setLastName(orderData.getLastName());
        fraudTicketPayload.setTimestamp(orderData.getTimestamp());
        fraudTicketPayload.setFraudScore(orderData.getFraudScore());
        fraudTicketPayload.setOrderCreationDate(orderData.getOrderCreationDate());
        fraudTicketPayload.setContactEmailId(orderData.getContactEmailId());
        fraudTicketPayload.setContactPhoneNumber(orderData.getContactPhoneNumber());
        fraudTicketPayload.setFraudReason(orderData.getFraudReason());
        return fraudTicketPayload;
    }

    private String createServiceUrl(String baseUrl, String merlotEndpoint, String ticketCategory) {
        Map<String, String> valuesMap = new HashMap<String, String>();
        valuesMap.put("ticketCategory", ticketCategory);
        String urlTemplateString = baseUrl + merlotEndpoint;
        StrSubstitutor substitutor = new StrSubstitutor(valuesMap, "{", "}");
        return substitutor.replace(urlTemplateString);
    }

    @Lookup
    protected BasicRestClient createBasicRestClient() {
        // This implementation will be overridden by spring.
        return null;
    }

    private BasicRestClient createMerlotRestClient() {
    	LOGGER.debug("Inside createMerlotRestClient.");
        //String cimaAccessToken = cimaClient.getBearerToken();
        int connectionTimeout = merlotProperties.getConnectionTimeout();
        int socketTimeout = merlotProperties.getSocketTimeout();

        HashMap<String, Object> headers = new HashMap<>();
        headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
        headers.put(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON);
        //headers.put(CLIENT_HEADER, merlotProperties.getClientValue());
        BasicRestClient restClient = createBasicRestClient();
//        restClient.setBearerAuth(true);
        restClient.setHeaders(headers);
//        restClient.setConsumerSecret(cimaAccessToken);
        restClient.setConnectionTimeout(Integer.toString(connectionTimeout));
        restClient.setSocketTimeout(Integer.toString(socketTimeout));
        return restClient;
    }

}
