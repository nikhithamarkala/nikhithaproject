package com.comcast.xfinity.mobile.notifications.domain.common;

public class ServiceException extends Exception {
    private static final long serialVersionUID = 2263327768911026299L;
    private Type type;
    private int status;
    public ServiceException(Type type) {
        this.type = type;
    }

    public ServiceException(String message, Type type) {
        super(message);
        this.type = type;
    }

    public ServiceException(String message, Throwable cause, Type type) {
        super(message, cause);
        this.type = type;
    }

    public ServiceException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace, Type type) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.type = type;
    }

    public ServiceException(Throwable cause, Type type) {
        super(cause);
        this.type = type;
    }

    public ServiceException(String message, int status) {
        super(message);
        this.status = status;
    }

    public Type getType() {
        return type;
    }

    public int getStatus() {
        return status;
    }

    public enum Type {
        BEARER_TOKEN,
        ESD_SERVICE,
        CIMA_TOKEN,
        CSP_SERVICE
    }
}
