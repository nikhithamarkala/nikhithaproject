package com.comcast.xfinity.mobile.notifications.domain.common;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Used to surface response details in swagger.
 *
 * @param <T>
 */
public class ParameterizedMspResponse<T> {
    private T data;
    private List<ErrorDescription> errors;
    private List<String> warnings;

    public ParameterizedMspResponse() {
        super();
        errors = new ArrayList<>();
        warnings = new ArrayList<>();
    }

    public ParameterizedMspResponse(List<ErrorDescription> errors, List<String> warnings) {
        super();
        this.errors = new ArrayList<>();
        this.errors = errors;
        this.warnings = new ArrayList<>();
        this.warnings = warnings;
    }

    public ParameterizedMspResponse(T obj, ErrorDescription error, String warning) {
        super();
        this.setData(obj);
        errors = new ArrayList<>();
        this.errors.add(error);
        warnings = new ArrayList<>();
        this.warnings.add(warning);
    }

    public ParameterizedMspResponse(ErrorDescription error, List<String> warnings) {
        super();
        errors = new ArrayList<>();
        this.errors.add(error);
        this.warnings = new ArrayList<>();
        this.warnings = warnings;
    }

    public ParameterizedMspResponse(ErrorDescription errorResponse) {
        super();
        errors = new ArrayList<>();
        this.errors.add(errorResponse);
        warnings = new ArrayList<>();
    }

    public ParameterizedMspResponse(T obj) {
        super();
        this.setData(obj);
        errors = new ArrayList<>();
        warnings = new ArrayList<>();
    }

    public ParameterizedMspResponse(T obj, ErrorDescription warning) {
        super();
        this.setData(obj);
        warnings = new ArrayList<>();
        this.warnings.add(warning.getMessage());
        errors = new ArrayList<>();
    }

    public ParameterizedMspResponse(T object, List<String> warnings) {
        super();
        this.setData(object);
        errors = new ArrayList<>();
        this.errors.isEmpty();
        this.warnings = new ArrayList<>();
        this.warnings = warnings;
    }

    public List<ErrorDescription> getError() {
        return errors;
    }

    public List<String> getWarnings() {
        return warnings;
    }

    public void setError(List<ErrorDescription> errors) {
        this.errors = errors;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public void addWarning(String warning) {
        this.warnings.add(warning);
    }

    public void addWarnings(List<String> warnings) {
        this.warnings.addAll(warnings);
    }

    public void setWarnings(List<String> warnings) {
        this.warnings = warnings;
    }

    public void addError(ErrorDescription error) {
        this.errors.add(error);
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }
}
