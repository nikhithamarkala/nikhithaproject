package com.comcast.xfinity.mobile.notifications.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import io.swagger.annotations.ApiModelProperty;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.EXISTING_PROPERTY, property = "eventType", visible = true)
@JsonSubTypes({ @JsonSubTypes.Type(value = OrderPlacedEventData.class, name = "ORDER_PLACED"),@JsonSubTypes.Type(value = FraudOrderEventData.class, name = "FRAUD_DETECTED"), @JsonSubTypes.Type(value = OrderStatusChangeEventData.class, name = "ORDER_CANCELED"),@JsonSubTypes.Type(value = OrderStatusChangeEventData.class, name = "ORDER_UPDATED")})
public abstract class EventData {

    @ApiModelProperty(hidden = true)
    private MbosEventType eventType;

    public MbosEventType getEventType() {
        return eventType;
    }

    public void setEventType(MbosEventType eventType) {
        this.eventType = eventType;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);

    }

}
