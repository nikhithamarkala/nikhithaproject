package com.comcast.xfinity.mobile.notifications.domain.account;

import java.util.ArrayList;
import java.util.Collection;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "AccountInformation", description = "AccountInformation resource representation")
public class AccountInformation {

    @ApiModelProperty(value = "Account Information", required = true)
    private CustomerInformationAccount accountInfo;

    @ApiModelProperty(value = "Users", required = true)
    private Collection<User> users = new ArrayList<User>();

    public AccountInformation() {
        super();
        this.accountInfo = null;
        this.users = null;
    }

    public AccountInformation(CustomerInformationAccount accountInfo, Collection<User> users) {
        super();
        this.accountInfo = accountInfo;
        this.users = users;
    }

    public CustomerInformationAccount getAccountInfo() {
        return accountInfo;
    }

    public void setAccountInfo(CustomerInformationAccount accountInfo) {
        this.accountInfo = accountInfo;
    }

    public Collection<User> getUsers() {
        return users;
    }

    public void setUsers(Collection<User> users) {
        this.users = users;
    }

    @Override
    public String toString() {

        StringBuilder friendlyStr = new StringBuilder();
        friendlyStr.append("AccountInformation [accountInfo=");
        friendlyStr.append(this.getAccountInfo() == null ? null : this.getAccountInfo());
        friendlyStr.append(", users=");
        friendlyStr.append(this.getUsers() == null ? null : this.getUsers());
        friendlyStr.append("]");

        return friendlyStr.toString();
    }

}
