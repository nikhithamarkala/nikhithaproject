/**
 * 
 */
package com.comcast.xfinity.mobile.notifications.domain.common;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * @author spatan001c
 *
 */
public class MspResponse {

	private Object data;
	private List<ErrorDescription> errors = new ArrayList<ErrorDescription>();
	private List<String> warnings = new ArrayList<String>();

	public MspResponse() {
		super();
	}

	public MspResponse(List<ErrorDescription> errors, List<String> warnings) {
		super();
		this.errors = errors;
		this.warnings = warnings;
	}

	public MspResponse(Object obj, ErrorDescription error, String warning) {
		super();
		this.setData(obj);
		this.errors.add(error);
		this.warnings.add(warning);
	}

	public MspResponse(ErrorDescription error, List<String> warnings) {
		super();
		this.errors.add(error);
		this.warnings = warnings;
	}

	public MspResponse(List<Object> objList) {
		super();
		this.setData(objList);
	}

	public MspResponse(ErrorDescription errorResponse) {
		super();
		this.errors.add(errorResponse);
	}

	public MspResponse(Object obj) {
		super();
		this.setData(obj);
	}

	public MspResponse(Object obj, ErrorDescription warning) {
		super();
		this.setData(obj);
		this.warnings.add(warning.getMessage());
	}

	public MspResponse(Object object, List<String> warnings) {
		super();
		this.setData(object);
		this.errors.isEmpty();
		this.warnings = warnings;
	}

	public List<ErrorDescription> getError() {
		return errors;
	}

	public List<String> getWarnings() {
		return warnings;
	}

	public void setError(List<ErrorDescription> errors) {
		this.errors = errors;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public void addWarning(String warning) {
		this.warnings.add(warning);
	}

	public void addWarnings(List<String> warnings) {
		this.warnings.addAll(warnings);
	}

	public void setWarnings(List<String> warnings) {
		this.warnings = warnings;
	}

	public void addError(ErrorDescription error) {
		this.errors.add(error);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
