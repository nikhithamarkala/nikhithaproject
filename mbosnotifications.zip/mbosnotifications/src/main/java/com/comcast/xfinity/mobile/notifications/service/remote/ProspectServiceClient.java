package com.comcast.xfinity.mobile.notifications.service.remote;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.comcast.xfinity.mobile.notifications.config.FeignClientConfiguration;
import com.comcast.xfinity.mobile.notifications.domain.account.AccountInformation;
import com.comcast.xfinity.mobile.notifications.domain.common.ParameterizedMspResponse;

/**
 * Feign client for accessing prospect service.
 */
@FeignClient(name = "prospect", configuration = FeignClientConfiguration.class)
public interface ProspectServiceClient {

    /**
     * returns the account details of given account guid.
     * 
     * @param accountGuid
     * @return
     */
    @RequestMapping(method = RequestMethod.GET, value = "/api/getcustomerinformation/{accountGuid}", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<ParameterizedMspResponse<AccountInformation>> getAccountInformation(@PathVariable("accountGuid") String accountGuid);
}