package com.comcast.xfinity.mobile.notifications.events;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

public interface MbosEventChannel {

    String ORDER_EVENT_CHANNEL = "order-events";
    String FRAUD_EVENT_CHANNEL = "fraud-events";

    @Input(MbosEventChannel.ORDER_EVENT_CHANNEL)
    SubscribableChannel orderEvents();

    @Input(MbosEventChannel.FRAUD_EVENT_CHANNEL)
    SubscribableChannel fraudEvents();
}
