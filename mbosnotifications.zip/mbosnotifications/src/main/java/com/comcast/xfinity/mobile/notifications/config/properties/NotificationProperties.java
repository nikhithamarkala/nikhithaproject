package com.comcast.xfinity.mobile.notifications.config.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

@ConfigurationProperties(prefix = "notifications")
public class NotificationProperties {

    private String cimaUrl;

    @NestedConfigurationProperty
    private EncryptionProperties encryption;

    @NestedConfigurationProperty
    private HttpClientProperties httpClient;

    @NestedConfigurationProperty
    private GrapevineProperties grapevineProperties;
    
    @NestedConfigurationProperty
    private MerlotProperties merlotProperties;

    public EncryptionProperties getEncryption() {
        return encryption;
    }

    public void setEncryption(EncryptionProperties encryption) {
        this.encryption = encryption;
    }

    public HttpClientProperties getHttpClient() {
        return httpClient;
    }

    public void setHttpClient(HttpClientProperties httpClient) {
        this.httpClient = httpClient;
    }


    public GrapevineProperties getGrapevineProperties() {
        return grapevineProperties;
    }

    public void setGrapevineProperties(GrapevineProperties grapevineProperties) {
        this.grapevineProperties = grapevineProperties;
    }

    public String getCimaUrl() {
        return cimaUrl;
    }

    public void setCimaUrl(String cimaUrl) {
        this.cimaUrl = cimaUrl;
    }

    public MerlotProperties getMerlotProperties() {
        return merlotProperties;
    }

    public void setMerlotProperties(MerlotProperties merlotProperties) {
        this.merlotProperties = merlotProperties;
    }

}
